

<?php $__env->startSection('content'); ?>


<section class="saf-registerpage">
	<div class="container">
	    <div class="row">
	        <div class="col-md-8">
	            <h1 class="main-title">Registration Form</h1>
	            <p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt consectetur adipiscing.</p>
	            <form class="registerfrm" action="<?php echo e(route('register')); ?>" method="POST" autocomplete="off" onsubmit="return submitRegistrationForm(this)">
	            	<?php echo csrf_field(); ?>
	                <div class="form-group">
	                    <label for="name">full name</label>
	                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="<?php echo e(old('name')); ?>" >

	                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                </div>
	                <div class="form-group">
		                <label for="male">Gender</label>
	                    <div class="gndr-block">
		                    <input type="radio" id="male" name="gender" value="male" class="" <?php echo e(old('gender') == 'male' ? 'checked' : ''); ?>>
		                    <label for="male">Male</label><br>
		                    <input type="radio" id="female" name="gender" value="female" class="" <?php echo e(old('gender') == 'female' ? 'checked' : ''); ?>>
		                    <label for="female">Female</label><br>
		                    <input type="radio" id="others" name="gender" value="others" class="" <?php echo e(old('gender') == 'others' ? 'checked' : ''); ?>>
		                    <label for="others">Others</label>
	                    </div>

	                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    	<input type="hidden" class="<?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                </div>

	                <div class="form-group">
	                    <label for="country">country</label>
	                    <input type="text" class="form-control <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="country" name="country" value="<?php echo e(old('country')); ?>" required>
	                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                </div>
	                <div class="form-group">
	                    <label for="city">city</label>
	                    <input type="text" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="city" name="city" value="<?php echo e(old('city')); ?>" required>
	                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                </div>
	                <div class="form-group">
	                    <label for="contact">contact number</label>
	                    <input type="text" class="form-control <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contact" name="contact" value="<?php echo e(old('contact')); ?>" required>
	                    <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                </div>
	                <div class="form-group">
	                    <label for="email">email id</label>
	                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e(old('email')); ?>" required>
	                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                </div>

	                <div class="form-group">
	                	<label for="email">Interests</label>
	                    <div class="chks checkbox-inline">
	                    	
	                    	<?php if($disciplines->count()): ?>
                                <?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   	<div class="chk-item">
				                        <input type="checkbox" id="interest_<?php echo e($discipline->id); ?>" name="interest[]" class="interest" value="<?php echo e($discipline->id); ?>" <?php echo e(old('interest') && in_array($discipline->id, old('interest')) ? 'checked' : ''); ?>>
				                        <label for="interest_<?php echo e($discipline->id); ?>" ><?php echo e($discipline->name); ?></label><br>
				                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <div class="chk-item">
		                        <input type="checkbox" onchange="allCheckClick(this)">
		                        <label for="all" >All</label><br>
		                    </div>
	                    
	                        <!-- <input type="checkbox" id="music" name="interest[]" class="interest" value="2">
	                        <label for="music" >Music</label><br>

	                        <input type="checkbox" id="dance" name="interest[]" class="interest" value="3">
	                        <label for="dance" >Dance</label><br>

	                        <input type="checkbox" id="theatre" name="interest[]" class="interest" value="4">
	                        <label for="theatre" >Theatre</label><br>

	                        <input type="checkbox" id="photography" name="interest[]" class="interest" value="5">
	                        <label for="photography" >Photography</label><br> -->
	                    
	                    </div>

	                    <?php $__errorArgs = ['interest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                    	<input type="hidden" class="<?php $__errorArgs = ['interest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                    <!-- <div class="chks">

		                    <div class="chk-item">
		                        <input type="checkbox" id="visualarts" name="interest[]" class="interest" value="6">
		                        <label for="visualarts" >Visual Arts</label><br>
		                    </div>

		                    <div class="chk-item">
		                        <input type="checkbox" id="culinaryarts" name="interest[]" class="interest" value="7">
		                        <label for="culinaryarts" >Culinary Arts</label><br>
		                    </div>
		                    
		                </div> -->

	                </div>

	                <div class="form-group acpt">
	                    <input type="checkbox" id="terms" name="terms" value="1" required="">
	                    <label for="terms" class="cpt"> I have read and understood the agreement.<br/> I accept and agree to all its <a href="<?php echo e(url('terms-conditions')); ?>" class="tc-btn">Terms and Conditions</a></label><br>

	                    <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	                </div>
	           
	                <div class="form-group">
	                    <input type="submit" value="Submit &LongRightArrow;">
	                </div>
	            </form>
	        </div>
	    </div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
    function allCheckClick(_this){
    	
    	if($(_this).is(':checked')){
    		$(".interest").prop('checked', true);
    	} else {

    		$(".interest").prop('checked', false);
    	}
    }

    function submitRegistrationForm(_this){
    	
    	if($("#terms").is(':checked')){
    		$(_this).submit();
    	}

    	alert("Please accpet terms & conditions");
    	return false;
    }

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/auth/register.blade.php ENDPATH**/ ?>