<?php $__env->startSection('content'); ?>
<style type="text/css">
	.image-input {
	    margin-right: 10px;
	}
	.image-input .image-input-wrapper {
	    width: 85px;
	    height: 85px;
	}
	.bootstrap-select>.dropdown-toggle.btn-light, .bootstrap-select>.dropdown-toggle.btn-secondary {
	    height: calc(1.5em + 1.65rem + 2px);
	    padding: 0.825rem 1.42rem;
	    font-size: 1.08rem;
	    line-height: 1.5;
	    border-radius: 0.42rem;
        background-color: #f3f6f9 !important;
    	border-color: #f3f6f9 !important;
	}
</style>
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class=" container ">
        <!--begin::Education-->
        <div class="d-flex flex-row">
            <!--begin::Aside-->
            <?php echo $__env->make('frontend/includes/aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--end::Aside-->
            <!--begin::Content-->
            <div class="flex-row-fluid ml-lg-8">

            	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            	
                <!--begin::Card-->
                <div class="card card-custom gutter-bs">

                    <!--Begin::Header-->
                    <div class="card-header">

		                <div class="card-title">
		                    <h3 class="card-label">Project Category Details</h3>
		                </div>
		            </div>
                    <!--end::Header-->

                    <!--Begin::Body-->
                    <div class="card-body">

                    	<?php echo $__env->make('frontend/category_details/category_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <!--end::Body-->

                	<form action="<?php echo e(route('update.category.details')); ?>" method="POST" enctype="multipart/form-data">
			            <input type="hidden" name="_method" value="PUT">
			            <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
			            <?php echo e(csrf_field()); ?>


	                    <!--Begin::Body-->
	                    <div class="card-body">

			                <div class="row">
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Project Name </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="project_id" tabindex="null" >
			                                    <option value="">Select</option>
			                                   	<?php if($projects->count()): ?>
			                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			                                           <option <?php echo e(old('project_id', $row->project_id ?? 0) ? 'selected' : ''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

			                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                    <?php endif; ?>
			                                </select>
			                                <?php $__errorArgs = ['project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">No. of team members </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">

			                            	<div class="input-group date">
												<input type="text" name="no_of_team_members" value="<?php echo e(old('no_of_team_members') ? old('no_of_team_members') : ( isset($row->no_of_team_members) ? $row->no_of_team_members : '')); ?>" class="form-control form-control-lg form-control-solid" placeholder="Enter No. of team members"/>

												<?php $__errorArgs = ['no_of_team_members'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

												
											</div>
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Brand Name</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="brand_name" value="<?php echo e(old('brand_name') ? old('brand_name') :( isset($row->brand_name) ? $row->brand_name : '')); ?>" class="form-control form-control-lg form-control-solid " maxlength="15"  placeholder="Enter Brand Name"/>
			                                <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>
			                
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Brand bio/ Note on brand</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="brand_bio" id="brand_bio" placeholder="Enter Brand bio/ Note on brand" require><?php echo e(old('brand_bio') ? old('brand_bio') : ( isset($row->brand_bio) ? $row->brand_bio : '')); ?></textarea>
			                                <?php $__errorArgs = ['brand_bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Brand Logo </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                
			                            	<div class="image-input image-input-outline" id="brand_logo" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->brand_logo) && !empty($row->brand_logo)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->brand_logo)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper brand_logo_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="brand_logo" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="brand_logo_remove"/>
												</label>

												<?php if(isset($row->brand_logo) && !empty($row->brand_logo)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

			                                <?php $__errorArgs = ['brand_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">High res images of the product</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                
			                            	<div class="image-input image-input-outline" id="high_res_images_of_the_product_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_product_1) && !empty($row->high_res_images_of_the_product_1)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_product_1)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_product_1_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_product_1" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_product_1_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_product_1) && !empty($row->high_res_images_of_the_product_1)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

											<div class="image-input image-input-outline" id="high_res_images_of_the_product_2" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_product_2) && !empty($row->high_res_images_of_the_product_2)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_product_2)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_product_2_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_product_2" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_product_2_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_product_2) && !empty($row->high_res_images_of_the_product_2)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

											<div class="image-input image-input-outline" id="high_res_images_of_the_product_3" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_product_3) && !empty($row->high_res_images_of_the_product_3)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_product_3)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_product_3_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_product_3" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_product_3_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_product_3) && !empty($row->high_res_images_of_the_product_3)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

			                                <?php $__errorArgs = ['high_res_images_of_the_product_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			                                <?php $__errorArgs = ['high_res_images_of_the_product_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			                                <?php $__errorArgs = ['high_res_images_of_the_product_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Video/ Youtube link</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">

			                            	<div class="input-group date">
												<input type="text" name="youtube_link" value="<?php echo e(old('youtube_link') ? old('youtube_link') : ( isset($row->youtube_link) ? $row->youtube_link : '')); ?>" class="form-control form-control-lg form-control-solid" placeholder="Enter video/ youtube link"/>

												<?php $__errorArgs = ['youtube_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

												
											</div>
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Menu/Inventory list of the products to be sold </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">

											<input type="file" name="inventory_list"  class="form-control form-control-lg form-control-solid  <?php $__errorArgs = ['inventory_list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
			                                Uploaded File: 
			                                <?php if($row->inventory_list): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->inventory_list)); ?>"><?php echo e($row->inventory_list); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>

											<?php $__errorArgs = ['inventory_list'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                        </div>
			                        </div>
			                    </div>
			                
			                	<div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">MRP of the products </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="file" name="mrp_of_the_products"  class="form-control form-control-lg form-control-solid  <?php $__errorArgs = ['mrp_of_the_products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
			                                Uploaded File: 
			                                <?php if($row->mrp_of_the_products): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->mrp_of_the_products)); ?>"><?php echo e($row->mrp_of_the_products); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
			                                <?php $__errorArgs = ['mrp_of_the_products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">HSN/SAC Code</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="hsn_sac_code" value="<?php echo e(old('hsn_sac_code') ? old('hsn_sac_code') :( isset($row->hsn_sac_code) ? $row->hsn_sac_code : '')); ?>" class="form-control form-control-lg form-control-solid " maxlength="15"  placeholder="Enter HSN/SAC Code"/>
			                                <?php $__errorArgs = ['hsn_sac_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Registration fees (if needed)</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="registration_fees" value="<?php echo e(old('registration_fees') ? old('registration_fees') : ( isset($row->registration_fees) ? $row->registration_fees : '')); ?>" class="form-control form-control-lg form-control-solid " maxlength="15"  placeholder="Enter Registration fees (if needed)"/>
			                                <?php $__errorArgs = ['registration_fees'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Table</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="tables" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('tables', $row->tables ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['tables'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">chair</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="chair" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('chair', $row->chair ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['chair'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">easel</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="easel" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('easel', $row->easel ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['easel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">fan</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="fan" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('fan', $row->fan ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['fan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">dustbin</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="dustbin" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('dustbin', $row->dustbin ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['dustbin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">lamp</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="lamp" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('lamp', $row->lamp ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['lamp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">lock</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="locks" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('locks', $row->locks ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['locks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">extension board</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="extension_board" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <?php $__currentLoopData = range(1, 50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                       <option <?php echo e(old('extension_board', $row->extension_board ?? 0) == $value ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($value); ?></option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                                </select>
			                                <?php $__errorArgs = ['extension_board'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Other Requirement</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="other_requirement" id="other_requirement" placeholder="Enter Other Requirement" require><?php echo e(old('other_requirement') ? old('other_requirement') : ( isset($row->other_requirement) ? $row->other_requirement : '')); ?></textarea>
			                                <?php $__errorArgs = ['other_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    
			                </div>
			                
			            </div>
	                    <!--end::Body-->

	                    <div class="card-footer">
			                <div class="row">
			                    <div class="col-lg-4"></div>
			                    <div class="col-lg-4 text-center">
			                        <button type="submit" class="btn btn-primary mr-2">Update</button>
			                    </div>
			                </div>
			            </div>
		            </form>

                </div>
                <!--end::Card-->
            </div>
            <!--end::Content-->
        </div>
        <!--end::Education-->
    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
    // START brand_logo
    var brand_logo = new KTImageInput('brand_logo');

	brand_logo.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	brand_logo.on('change', function(imageInput) {

		
	});

	brand_logo.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END brand_logo

	// START high_res_images_of_the_product_1
    var high_res_images_of_the_product_1 = new KTImageInput('high_res_images_of_the_product_1');

	high_res_images_of_the_product_1.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_product_1.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_product_1.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_product_1

	// START high_res_images_of_the_product_2
    var high_res_images_of_the_product_2 = new KTImageInput('high_res_images_of_the_product_2');

	high_res_images_of_the_product_2.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_product_2.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_product_2.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_product_2

	// START high_res_images_of_the_product_3
    var high_res_images_of_the_product_3 = new KTImageInput('high_res_images_of_the_product_3');

	high_res_images_of_the_product_3.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_product_3.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_product_3.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_product_3

	
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/frontend/category_details/vendorssaf/edit.blade.php ENDPATH**/ ?>