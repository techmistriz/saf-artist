

<?php $__env->startSection('content'); ?>
<style type="text/css">
	.radio {
		display: -webkit-box;
	}

	.image-input {
	    margin-right: 10px;
	}

	.image-input .image-input-wrapper {
	    width: 85px;
	    height: 85px;
	}

	.form-control-custom, .input-group-text {
		background-color: transparent !important;
	    border: none; 
	    border-bottom: 1px solid #F7EAD3; 
	    border-radius: 0;
	    color: #F7EAD3 !important;
	}

	input.form-control-custom::placeholder {
	  font-size: 12px;
	  letter-spacing: 1px;
	  line-height: 16px;
	  color: #F7EAD3;
	  font-family: 'Open Sans', sans-serif;
	  text-transform: uppercase;
	  opacity: 0.7;
	}

	textarea.form-control-custom::placeholder {
	  font-size: 12px;
	  letter-spacing: 1px;
	  line-height: 16px;
	  color: #F7EAD3;
	  font-family: 'Open Sans', sans-serif;
	  text-transform: uppercase;
	  opacity: 0.7;
	}

	input.form-control-custom:focus {
	    outline: none;
	    background: none;
	    border-bottom: 2px solid #F7EAD3;
	}

	.input-group-text .la{
		color: #F7EAD3;
	}

	.radio>span {
	    background-color: transparent;
	    border: 1px solid #F7EAD3;
	}

	.radio>input:checked~span{
		background-color: #F7EAD3;
	}

	.radio>input:checked~span:after {
	    background-color: #981e3d;
	    border-color: #981e3d;
	}

	.btn.btn-light.focus:not(.btn-text), .btn.btn-light:focus:not(.btn-text), .btn.btn-light:hover:not(.btn-text):not(:disabled):not(.disabled) {
	    color: #F7EAD3;
	    background-color: transparent !important;
	    border-color: #F7EAD3;
	}

	.bootstrap-select>.dropdown-toggle.btn-light, .bootstrap-select>.dropdown-toggle.btn-secondary {
	    background: transparent !important;
	    color: #F7EAD3;
	    border-color: #F7EAD3!important;
	    -webkit-box-shadow: none;
	    box-shadow: none;
	}

	.bootstrap-select>.dropdown-toggle.btn-light .filter-option, .bootstrap-select>.dropdown-toggle.btn-secondary .filter-option {
	    color: #F7EAD3;
	}

	.btn.btn-light.dropdown-toggle:after {
	    color: #F7EAD3;
	}

	.btn.btn-light.focus:not(.btn-text).dropdown-toggle:after, .btn.btn-light:focus:not(.btn-text).dropdown-toggle:after, .btn.btn-light:hover:not(.btn-text):not(:disabled):not(.disabled).dropdown-toggle:after {
	    color: #F7EAD3;
	}

</style>

<section class="cntform">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                <div class="logo-sa">
                    <img src="<?php echo e(url('/image/Logo-SVG.svg')); ?>" alt="Image"/>
                </div>
            </div>
        </div>


        <div class="row justify-content-center">
	        <div class="col-md-10">

		        <div class="flex-row-fluid">
		            <!--begin::Card-->
		            <div class="card card-custom gutter-bs theme-bg">
		            	<form action="<?php echo e(route('user.register')); ?>" method="POST" enctype="multipart/form-data" class="register-form">

				            <?php echo e(csrf_field()); ?>


		                    <!--Begin::Body-->
		                    <div class="card-body">

		                    	<div class="row">
				                    <div class="col-12">
				                    	<div class="card-title">
						                    <h3 class="card-label text-center theme-text-color">FILL YOUR DETAILS</h3>
					                	</div>
				                	</div>
				                </div>

		                    	<div class="row">
				                    <div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="name" value="<?php echo e(old('name') ? old('name') :( isset($row->name) ? $row->name : '')); ?>" class="form-control form-control-lg form-control-custom"  placeholder="Enter Full Name"/>
				                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            </div>
				                        </div>
				                    </div>
				                    
				                    <div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                               
				                               	<div class="radio-inline">
											        <label class="radio theme-text-color">
											            <input type="radio" name="gender" value="male" <?php echo e((old('gender') == 'male' || (!isset($row->gender) || empty($row->gender)) ) ? 'checked' : ( isset($row->gender) && $row->gender == 'male' ? 'checked' : '')); ?> />
											            <span></span>
											            Male
											        </label>
											        <label class="radio theme-text-color">
											            <input type="radio" name="gender" value="female" <?php echo e((old('gender') == 'female' ) ? 'checked' : ( isset($row->gender) && $row->gender == 'female' ? 'checked' : '')); ?> />
											            <span></span>
											            Female
											        </label>

											        <label class="radio theme-text-color">
											            <input type="radio" name="gender" value="others" <?php echo e((old('gender') == 'others' ) ? 'checked' : ( isset($row->gender) && $row->gender == 'others' ? 'checked' : '')); ?> />
											            <span></span>
											            Others
											        </label>
											        
											    </div>

				                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            </div>
				                        </div>
				                    </div>
				                    
				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" oninput="this.value=this.value.replace(/[^0-9]/, '')" name="age" value="<?php echo e(old('age') ? old('age') :( isset($row->age) ? $row->age : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Age"/>
				                                <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                    
				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">

				                            	<div class="input-group date">
													<input type="text" name="dob" value="<?php echo e(old('dob') ? old('dob') : ( isset($row->dob) ? $row->dob : '')); ?>" class="form-control form-control-lg form-control-custom kt_datepicker" <?php echo e(isset($row->dob) ? '':''); ?> placeholder="Enter DOB" autocomplete="new dob" readonly />

													<?php $__errorArgs = ['vip_seats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
					                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

													<div class="input-group-append">
														<span class="input-group-text">
															<i class="la la-calendar-check-o"></i>
														</span>
													</div>
												</div>
				                            </div>
				                        </div>
				                    </div>
				                    
				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" oninput="this.value=this.value.replace(/[^0-9]/, '')" name="contact" value="<?php echo e(old('contact') ? old('contact') :( isset($row->contact) ? $row->contact : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Contact"/>
				                                <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                    
				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="email" value="<?php echo e(old('email') ? old('email') : ( isset($row->email) ? $row->email : '')); ?>" class="form-control form-control-lg form-control-custom"  placeholder="Enter Email"/>
				                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                    <div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <textarea class="form-control form-control-lg form-control-custom no-summernote-editor" name="permanent_address" id="permanent_address" placeholder="Enter Permanent Address" require><?php echo e(old('permanent_address') ? old('permanent_address') : ( isset($row->permanent_address) ? $row->permanent_address : '')); ?></textarea>
				                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                	
				                	<div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="pa_city" value="<?php echo e(old('pa_city') ? old('pa_city') :( isset($row->pa_city) ? $row->pa_city : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter City"/>
				                                <?php $__errorArgs = ['pa_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="pa_state" value="<?php echo e(old('pa_state') ? old('pa_state') :( isset($row->pa_state) ? $row->pa_state : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter State"/>
				                                <?php $__errorArgs = ['pa_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                    
				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="pa_country" value="<?php echo e(old('pa_country') ? old('pa_country') :( isset($row->pa_country) ? $row->pa_country : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Country"/>
				                                <?php $__errorArgs = ['pa_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="pa_pincode" value="<?php echo e(old('pa_pincode') ? old('pa_pincode') :( isset($row->pa_pincode) ? $row->pa_pincode : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Pincode"/>
				                                <?php $__errorArgs = ['pa_pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <textarea class="form-control form-control-lg form-control-custom no-summernote-editor" name="current_address" id="current_address" placeholder="Enter Current Address" require><?php echo e(old('current_address') ? old('current_address') : ( isset($row->current_address) ? $row->current_address : '')); ?></textarea>
				                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="ca_city" value="<?php echo e(old('ca_city') ? old('ca_city') :( isset($row->ca_city) ? $row->ca_city : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter City"/>
				                                <?php $__errorArgs = ['ca_city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="ca_state" value="<?php echo e(old('ca_state') ? old('ca_state') :( isset($row->ca_state) ? $row->ca_state : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter State"/>
				                                <?php $__errorArgs = ['ca_state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                    
				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="ca_country" value="<?php echo e(old('ca_country') ? old('ca_country') :( isset($row->ca_country) ? $row->ca_country : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Country"/>
				                                <?php $__errorArgs = ['ca_country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-3">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="ca_pincode" value="<?php echo e(old('ca_pincode') ? old('ca_pincode') :( isset($row->ca_pincode) ? $row->ca_pincode : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Pincode"/>
				                                <?php $__errorArgs = ['ca_pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <select class="form-control form-control-lg form-control-custom selectpicker" name="address_proof_type" tabindex="null" >
				                                    <option value="" data-slug="">Select Address Proof</option>
				                                    <?php if($addressProofs->count()): ?>
				                                        <?php $__currentLoopData = $addressProofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				                                           <option <?php echo e(!empty(old('address_proof_type')) && old('address_proof_type') == $value->id ? 'selected' : ( isset($row->address_proof_type) && $row->address_proof_type == $value->id ? 'selected' : '' )); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

				                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                                    <?php endif; ?>
				                                </select>

				                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-6">

				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                
				                            	<div class="image-input image-input-outline" id="address_proof_file" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

				                            		<?php if(isset($row->address_proof_image) && !empty($row->address_proof_image)): ?>
														<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->address_proof_image)); ?>)"></div>
				                            		<?php else: ?>
				                            			<div class="image-input-wrapper address_proof_image_base64"></div>
				                            		<?php endif; ?>

													<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
														<i class="fa fa-pen icon-sm text-muted"></i>
														<input type="file" name="address_proof_image" accept=".png, .jpg, .jpeg"/>
														<input type="hidden" name="address_proof_image_remove"/>
													</label>

													<?php if(isset($row->address_proof_image) && !empty($row->address_proof_image)): ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php else: ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php endif; ?>
												</div>

				                                <?php $__errorArgs = ['address_proof_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                    <div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <textarea class="form-control form-control-lg form-control-custom no-summernote-editor" name="stage_name" id="stage_name" placeholder="Enter Stage Name" require><?php echo e(old('stage_name') ? old('stage_name') : ( isset($row->stage_name) ? $row->stage_name : '')); ?></textarea>
				                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                    <div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <textarea class="form-control form-control-lg form-control-custom summernote-editor" name="artist_bio" id="artist_bio" placeholder="Enter Artist Bio" require><?php echo e(old('artist_bio') ? old('artist_bio') : ( isset($row->artist_bio) ? $row->artist_bio : '')); ?></textarea>
				                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				               
				                	<div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="instagram_urername" value="<?php echo e(old('instagram_urername') ? old('instagram_urername') :( isset($row->instagram_urername) ? $row->instagram_urername : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Instagram Username"/>
				                                <?php $__errorArgs = ['instagram_urername'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="instagram_url" value="<?php echo e(old('instagram_url') ? old('instagram_url') :( isset($row->instagram_url) ? $row->instagram_url : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Instagram URL"/>
				                                <?php $__errorArgs = ['instagram_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="facebook_username" value="<?php echo e(old('facebook_username') ? old('facebook_username') :( isset($row->facebook_username) ? $row->facebook_username : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Facebook Username"/>
				                                <?php $__errorArgs = ['facebook_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="facebook_url" value="<?php echo e(old('facebook_url') ? old('facebook_url') :( isset($row->facebook_url) ? $row->facebook_url : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Facebook URL"/>
				                                <?php $__errorArgs = ['facebook_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="linkdin_username" value="<?php echo e(old('linkdin_username') ? old('linkdin_username') :( isset($row->linkdin_username) ? $row->linkdin_username : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Linkdin Username"/>
				                                <?php $__errorArgs = ['linkdin_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="linkdin_url" value="<?php echo e(old('linkdin_url') ? old('linkdin_url') :( isset($row->linkdin_url) ? $row->linkdin_url : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Linkdin URL"/>
				                                <?php $__errorArgs = ['linkdin_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="twitter_username" value="<?php echo e(old('twitter_username') ? old('twitter_username') :( isset($row->twitter_username) ? $row->twitter_username : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Twitter Username"/>
				                                <?php $__errorArgs = ['twitter_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="twitter_url" value="<?php echo e(old('twitter_url') ? old('twitter_url') :( isset($row->twitter_url) ? $row->twitter_url : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Country"/>
				                                <?php $__errorArgs = ['twitter_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="website" value="<?php echo e(old('website') ? old('website') :( isset($row->website) ? $row->website : '')); ?>" class="form-control form-control-lg form-control-custom"   placeholder="Enter Website"/>
				                                <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                
				                            	<div class="image-input image-input-outline" id="practice_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

				                            		<?php if(isset($row->practice_image_1) && !empty($row->practice_image_1)): ?>
														<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->practice_image_1)); ?>)"></div>
				                            		<?php else: ?>
				                            			<div class="image-input-wrapper practice_image_1_base64"></div>
				                            		<?php endif; ?>

													<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
														<i class="fa fa-pen icon-sm text-muted"></i>
														<input type="file" name="practice_image_1" accept=".png, .jpg, .jpeg"/>
														<input type="hidden" name="practice_image_1_remove"/>
													</label>

													<?php if(isset($row->practice_image_1) && !empty($row->practice_image_1)): ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php else: ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php endif; ?>
												</div>

												<div class="image-input image-input-outline" id="practice_image_2" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

				                            		<?php if(isset($row->practice_image_2) && !empty($row->practice_image_2)): ?>
														<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->practice_image_2)); ?>)"></div>
				                            		<?php else: ?>
				                            			<div class="image-input-wrapper practice_image_2_base64"></div>
				                            		<?php endif; ?>

													<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
														<i class="fa fa-pen icon-sm text-muted"></i>
														<input type="file" name="practice_image_2" accept=".png, .jpg, .jpeg"/>
														<input type="hidden" name="practice_image_2_remove"/>
													</label>

													<?php if(isset($row->practice_image_2) && !empty($row->practice_image_2)): ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php else: ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php endif; ?>
												</div>

												<div class="image-input image-input-outline" id="practice_image_3" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

				                            		<?php if(isset($row->practice_image_3) && !empty($row->practice_image_3)): ?>
														<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->practice_image_3)); ?>)"></div>
				                            		<?php else: ?>
				                            			<div class="image-input-wrapper practice_image_3_base64"></div>
				                            		<?php endif; ?>

													<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
														<i class="fa fa-pen icon-sm text-muted"></i>
														<input type="file" name="practice_image_3" accept=".png, .jpg, .jpeg"/>
														<input type="hidden" name="practice_image_3_remove"/>
													</label>

													<?php if(isset($row->practice_image_3) && !empty($row->practice_image_3)): ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php else: ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php endif; ?>
												</div>

				                                <?php $__errorArgs = ['practice_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

				                                <?php $__errorArgs = ['practice_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

				                                <?php $__errorArgs = ['practice_image_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-6">

				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                
				                            	<div class="image-input image-input-outline" id="profile_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

				                            		<?php if(isset($row->profile_image_1) && !empty($row->profile_image_1)): ?>
														<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->profile_image_1)); ?>)"></div>
				                            		<?php else: ?>
				                            			<div class="image-input-wrapper profile_image_1_base64"></div>
				                            		<?php endif; ?>

													<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
														<i class="fa fa-pen icon-sm text-muted"></i>
														<input type="file" name="profile_image_1" accept=".png, .jpg, .jpeg"/>
														<input type="hidden" name="profile_image_1_remove"/>
													</label>

													<?php if(isset($row->profile_image_1) && !empty($row->profile_image_1)): ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php else: ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php endif; ?>
												</div>

												<div class="image-input image-input-outline" id="profile_image_2" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

				                            		<?php if(isset($row->profile_image_2) && !empty($row->profile_image_2)): ?>
														<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->profile_image_2)); ?>)"></div>
				                            		<?php else: ?>
				                            			<div class="image-input-wrapper profile_image_2_base64"></div>
				                            		<?php endif; ?>

													<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
														<i class="fa fa-pen icon-sm text-muted"></i>
														<input type="file" name="profile_image_2" accept=".png, .jpg, .jpeg"/>
														<input type="hidden" name="profile_image_2_remove"/>
													</label>

													<?php if(isset($row->profile_image_2) && !empty($row->profile_image_2)): ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php else: ?>
														<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
															<i class="ki ki-bold-close icon-xs text-muted"></i>
														</span>
				                            		<?php endif; ?>
												</div>

				                                <?php $__errorArgs = ['profile_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

				                                <?php $__errorArgs = ['profile_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>
				                
				                	<div class="col-12">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <select class="form-control form-control-lg form-control-custom selectpicker" name="has_serendipity_arts" tabindex="null" onchange="serendipityArtsChangePress(this)">
				                                    <option value="">Have you been associated with Serendipity Arts in the past ?</option>
				                                    <option value="Yes" <?php echo e(old('has_serendipity_arts') == 'Yes' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'Yes') ? 'selected' : ''); ?>>Yes</option>
				                                    <option value="No" <?php echo e(old('has_serendipity_arts') == 'No' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'No') ? 'selected' : ''); ?>>No</option>
				                                </select>

				                                <?php $__errorArgs = ['has_serendipity_arts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                    <div class="col-12 has-year" style="display: none;">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <select class="form-control form-control-lg form-control-custom selectpicker" name="year" tabindex="null" >
				                                    <option value="">Select Year</option>
				                                    <?php if( isset($years) && count($years)): ?>
				                                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				                                           <option <?php echo e(!empty(old('year')) && old('year') == $year ? 'selected' : ( isset($row->year) && $row->year == $year ? 'selected' : '' )); ?> value="<?php echo e($year); ?>"><?php echo e($year); ?></option>

				                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                                    <?php endif; ?>
				                                </select>

				                                <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                	<div class="col-6">
				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <input type="text" name="other_link" value="<?php echo e(old('other_link') ? old('other_link') :( isset($row->other_link) ? $row->other_link : '')); ?>" class="form-control form-control-lg form-control-custom"  placeholder="Enter Any Other Relevant Links"/>
				                                <?php $__errorArgs = ['other_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            </div>
				                        </div>
				                    </div>
					                    
				                	<div class="col-6">

				                        <div class="form-group row validated">
				                            <div class="col-lg-12 col-md-12 col-sm-12">
				                                <select class="form-control form-control-lg form-control-custom selectpicker" name="category_id" tabindex="null" >
				                                    <option value="" data-slug="">Select Category</option>
				                                    <?php if($categories->count()): ?>
				                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				                                           <option <?php echo e(!empty(old('category_id')) && old('category_id') == $category->id ? 'selected' : ( isset($row->category_id) && $row->category_id == $category->id ? 'selected' : '' )); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

				                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                                    <?php endif; ?>
				                                </select>

				                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				                            
				                            </div>
				                        </div>
				                    </div>

				                </div>
				                <div class="row  mt-10">
				                    <div class="col-lg-12 text-center">
				                        <button type="submit" class="theme-btn">REGISTER</button>
				                        <!-- <a class="theme-btn"> REGISTER</a> -->
				                        <!-- <input type="submit" class="theme-btn" name="" value="REGISTER"> -->
				                    </div>
				                </div>

		                    </div>
		                    <!--end::Body-->
		                   
				        </form>

		            </div>
		            <!--end::Card-->
		        </div>
	        </div>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
    // START address_proof_file
    var address_proof_file = new KTImageInput('address_proof_file');

	address_proof_file.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	address_proof_file.on('change', function(imageInput) {

		// swal.fire({
		// 	title: 'Image successfully uploaded !',
		// 	type: 'error',
		// 	buttonsStyling: false,
		// 	confirmButtonText: 'Okay!',
		// 	confirmButtonClass: 'btn btn-primary font-weight-bold'
		// });
		
	});

	address_proof_file.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END address_proof_file


	// START practice_image_1
    var practice_image_1 = new KTImageInput('practice_image_1');

	practice_image_1.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	practice_image_1.on('change', function(imageInput) {
		
	});

	practice_image_1.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END practice_image_1

	// START practice_image_2
    var practice_image_2 = new KTImageInput('practice_image_2');

	practice_image_2.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	practice_image_2.on('change', function(imageInput) {
		
	});

	practice_image_2.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END practice_image_2

	// START practice_image_3
    var practice_image_3 = new KTImageInput('practice_image_3');

	practice_image_3.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	practice_image_3.on('change', function(imageInput) {
		
	});

	practice_image_3.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END practice_image_3

	// START profile_image_1
    var profile_image_1 = new KTImageInput('profile_image_1');

	profile_image_1.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	profile_image_1.on('change', function(imageInput) {
		
	});

	profile_image_1.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END profile_image_1

	// START profile_image_2
    var profile_image_2 = new KTImageInput('profile_image_2');

	profile_image_2.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	profile_image_2.on('change', function(imageInput) {
		
	});

	profile_image_2.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END profile_image_2

	function serendipityArtsChangePress(_this){

		if($(_this).val() == 'Yes'){
			$(".has-year").show();
		} else {

			$(".has-year").hide();
		}
	}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\artist\resources\views/home.blade.php ENDPATH**/ ?>