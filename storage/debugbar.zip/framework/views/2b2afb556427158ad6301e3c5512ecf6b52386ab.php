<?php $__env->startSection('content'); ?>

<style type="text/css">
    .radio {
        display: -webkit-box;
    }

    .image-input {
        margin-right: 10px;
    }

    .bootstrap-select>.dropdown-toggle.btn-light, .bootstrap-select>.dropdown-toggle.btn-secondary {
        height: calc(1.5em + 1.65rem + 2px);
        padding: 0.825rem 1.42rem;
        font-size: 1.08rem;
        line-height: 1.5;
        border-radius: 0.42rem;
        background-color: #f3f6f9 !important;
        border-color: #f3f6f9 !important;
    }
</style>

<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class=" container container-fluid">

        

        <!--begin::Education-->
        <div class="d-flex flex-row">
            <!--begin::Aside-->
            <?php echo $__env->make('frontend/includes/aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--end::Aside-->
            <!--begin::Content-->
            <div class="flex-row-fluid ml-lg-8">
                <!--begin::Card-->
                <div class="card card-custom gutter-bs">
                    <form action="<?php echo e(route('update.profile')); ?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="_method" value="PUT">
                        <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
                        <?php echo e(csrf_field()); ?>


                        <!--Begin::Header-->
                        <div class="card-header">

                            <?php echo $__env->make('includes.common.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <div class="card-title">
                                <h3 class="card-label">Artist Personal Details</h3>
                            </div>
                        </div>
                        <!--end::Header-->
                        <!--Begin::Body-->
                        <div class="card-body">
                            <div class="row">

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Are you Artist/group </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <select class="form-control form-control-lg form-control-custom selectpicker" name="frontend_role_id" tabindex="null" >
                                                <option value="">Select Role</option>
                                                <?php if($frontendRoles->count()): ?>
                                                    <?php $__currentLoopData = $frontendRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value->id); ?>" <?php echo e(old('frontend_role_id', $row->frontend_role_id ?? 0) == $value->id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                            <?php $__errorArgs = ['frontend_role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Category </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <select name="category_id" id="category_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="">Select Category</option>

                                                <?php if($categories->count()): ?>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value->id); ?>" <?php echo e(old('category_id', $row->category_id ?? 0) == $value->id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </select>
                                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Name of Curators </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <select name="curator_name" id="curator_name" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['curator_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="">Select Curator</option>

                                                <?php if($curators->count()): ?>
                                                    <?php $__currentLoopData = $curators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value->name); ?>" <?php echo e(old('curator_name', $row->curator_name ?? '') == $value->name ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </select>
                                            <?php $__errorArgs = ['curator_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Artist Type</label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <select name="artist_type_id" id="artist_type_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['artist_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="">Select Artist Type</option>

                                                <?php if($artistTypes->count()): ?>
                                                    <?php $__currentLoopData = $artistTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($value->id); ?>" <?php echo e(old('artist_type_id', $row->artist_type_id ?? 0) == $value->id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </select>
                                            <?php $__errorArgs = ['artist_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Full Name </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" value="<?php echo e($row->name ?? ''); ?>" class="form-control form-control-lg form-control-solid" placeholder="Enter Full Name" readonly />
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">DOB </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">

                                            <div class="input-group date">
                                                <input type="text" name="dob" value="<?php echo e(old('dob') ? old('dob') : ( isset($row->dob) ? $row->dob : '')); ?>" class="form-control form-control-lg form-control-solid kt_datepicker" <?php echo e(isset($row->dob) ? '':''); ?> placeholder="Enter DOB" autocomplete="new dob" readonly />

                                                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                <div class="input-group-append">
                                                    <span class="input-group-text">
                                                        <i class="la la-calendar-check-o"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Contact </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">

                                            <div class="row">
                                                <div class="col-lg-3 col-md-3 col-sm-3">
                                                    <select name="country_code" id="country_code" class="form-control form-control-lg form-control-solid form-control-custom selectpicker <?php $__errorArgs = ['country_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <option value="">Select</option>

                                                        <?php if($countries->count()): ?>
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($country->std_code != ''): ?>
                                                                    <option value="<?php echo e($country->std_code); ?>" <?php echo e(old('country_code', $row->country_code ?? 0) == $country->std_code ? 'selected' : ''); ?>><?php echo e($country->std_code); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>

                                                    </select>
                                                    <?php $__errorArgs = ['country_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-lg-9 col-md-9 col-sm-9">
                                                    <input type="text" oninput="this.value=this.value.replace(/[^0-9]/, '')"  value="<?php echo e($row->contact ?? ''); ?>" class="form-control form-control-lg form-control-solid" minlength="10" maxlength="10"  placeholder="Enter Contact" readonly/>
                                                    <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Email </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" value="<?php echo e($row->email ?? ''); ?>" class="form-control form-control-lg form-control-solid" placeholder="Enter Email" readonly />
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Address </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="permanent_address" id="permanent_address" placeholder="Enter Address"><?php echo e(old('permanent_address', $row->permanent_address ?? '')); ?></textarea>
                                            <?php $__errorArgs = ['permanent_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Country </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <select name="pa_country_id" id="pa_country_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['pa_country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="getStates(this, 'pa_country_id', 'pa_state_id', 'State'); checkOtherCountry(this)">
                                                <option value="">Select Country</option>

                                                <?php if($countries->count()): ?>
                                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($country->id); ?>" <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == $country->id ? 'selected' : ''); ?>><?php echo e($country->country_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </select>
                                            <?php $__errorArgs = ['pa_country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 pa-country-other" style="display: <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == 2 ? '' : 'none'); ?>">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Country - Other </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">

                                            <input type="text" name="pa_country_other" value="<?php echo e(old('pa_country_other', $row->pa_country_other ?? '')); ?>" class="form-control form-control-solid form-control-lg" placeholder="Enter Country - Other" />

                                            <?php $__errorArgs = ['pa_country_other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 state-wrapper" style="display: <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == 2 ? 'none' : ''); ?>">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">State </label>
                                            <div class="col-lg-9 col-md-9 col-sm-12">
                                            
                                            <select name="pa_state_id" id="pa_state_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['pa_state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-live-search="true" onchange="getCities(this, 'pa_state_id', 'pa_city_id', 'City')">
                                                <option value="">Select State</option>

                                            </select>

                                            <?php $__errorArgs = ['pa_state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-12 state-wrapper" style="display: <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == 2 ? 'none' : ''); ?>">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">City</label>
                                            <div class="col-lg-9 col-md-9 col-sm-12">
                                           
                                            <select name="pa_city_id" id="pa_city_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['pa_city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-live-search="true" onchange="checkOtherCity(this, 'pa-city-other')">
                                                <option value="">Select City</option>

                                            </select>

                                            <?php $__errorArgs = ['pa_city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 pa-city-other" style="display: <?php echo e(old('pa_city_id', $row->pa_city_id ?? 0) == 7934 ? '' : 'none'); ?>">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">City - Other </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">

                                            <input type="text" name="pa_city_other" value="<?php echo e(old('pa_city_other', $row->pa_city_other ?? '')); ?>" class="form-control form-control-solid form-control-lg" placeholder="Enter City - Other" />

                                            <?php $__errorArgs = ['pa_city_other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Pincode </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="pa_pincode" value="<?php echo e(old('pa_pincode') ? old('pa_pincode') :( isset($row->pa_pincode) ? $row->pa_pincode : '')); ?>" class="form-control form-control-lg form-control-solid"  minlength="6" maxlength="6"  placeholder="Enter Pincode"/>
                                            <?php $__errorArgs = ['pa_pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Company/Collective (If Applicable) </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="company_collective" id="company_collective" placeholder="Enter Company/Collective"><?php echo e(old('company_collective', $row->company_collective ?? '')); ?></textarea>
                                            <?php $__errorArgs = ['company_collective'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row">

                                <div class="col-12">
                                    <h4 class="card-label">For marketing and social media purpose</h4><hr>
                                </div>

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Stage Name <i>(If Any)</i> </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="stage_name" id="stage_name" placeholder="Enter Stage Name" maxlength="150"><?php echo e(old('stage_name') ? old('stage_name') : ( isset($row->stage_name) ? $row->stage_name : '')); ?></textarea>
                                            <?php $__errorArgs = ['stage_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Artist Bio <i>(150 words only) </i> </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="artist_bio" id="artist_bio" placeholder="Enter Artist Bio"><?php echo e(old('artist_bio') ? old('artist_bio') : ( isset($row->artist_bio) ? $row->artist_bio : '')); ?></textarea>
                                            <?php $__errorArgs = ['artist_bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Instagram Profile Link </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="instagram_url" value="<?php echo e(old('instagram_url') ? old('instagram_url') :( isset($row->instagram_url) ? $row->instagram_url : '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Instagram Profile Link"/>
                                            <?php $__errorArgs = ['instagram_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Facebook Profile Link </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="facebook_url" value="<?php echo e(old('facebook_url') ? old('facebook_url') :( isset($row->facebook_url) ? $row->facebook_url : '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Facebook Profile Link"/>
                                            <?php $__errorArgs = ['facebook_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Linkdin Profile Link </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="linkdin_url" value="<?php echo e(old('linkdin_url') ? old('linkdin_url') :( isset($row->linkdin_url) ? $row->linkdin_url : '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Linkdin Profile Link"/>
                                            <?php $__errorArgs = ['linkdin_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Twitter Profile Link </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="twitter_url" value="<?php echo e(old('twitter_url') ? old('twitter_url') :( isset($row->twitter_url) ? $row->twitter_url : '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Twitter Profile Link"/>
                                            <?php $__errorArgs = ['twitter_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Website <i>(If any)</i> </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="website" value="<?php echo e(old('website') ? old('website') :( isset($row->website) ? $row->website : '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Website"/>
                                            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Please upload 3 high resolutions images of your practice (for use on social media and print collaterals)</label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            
                                            <div class="row pb-5">
                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                    
                                                    <input type="file" name="practice_image_1"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['practice_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                                    <p class="text-muted small">( 5 MB to 10MB and 300 dpi )</p>
                                                    
                                                    Uploaded File: 
                                                    <?php if($row->practice_image_1): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_1)); ?>"><?php echo e($row->practice_image_1); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>

                                                    <?php $__errorArgs = ['practice_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                                </div>
                                            </div>
                                            <div class="row pb-5">
                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                    
                                                    <input type="file" name="practice_image_2"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['practice_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                                    <p class="text-muted small">( 5 MB to 10MB and 300 dpi )</p>
                                                    Uploaded File: 
                                                    <?php if($row->practice_image_2): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_2)); ?>"><?php echo e($row->practice_image_2); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>

                                                    <?php $__errorArgs = ['practice_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                                </div>
                                            </div>

                                            <div class="row pb-5">
                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                    
                                                    <input type="file" name="practice_image_3"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['practice_image_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                                    <p class="text-muted small">( 5 MB to 10MB and 300 dpi )</p>
                                                    Uploaded File: 
                                                    <?php if($row->practice_image_3): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_3)); ?>"><?php echo e($row->practice_image_3); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>

                                                    <?php $__errorArgs = ['practice_image_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                                </div>
                                            </div>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">

                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Please upload 2 high resolution profile images (For your festival ID and promotion)</label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            
                                            <div class="row pb-5">
                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                    
                                                    <input type="file" name="profile_image_1"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['profile_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                                    <p class="text-muted small">( Please save file name as the Credit name )</p>
                                                    Uploaded File: 
                                                    <?php if($row->profile_image_1): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->profile_image_1)); ?>"><?php echo e($row->profile_image_1); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>

                                                    <?php $__errorArgs = ['profile_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                                </div>
                                            </div>

                                            <div class="row pb-5">
                                                <div class="col-lg-12 col-md-12 col-sm-12">
                                                    
                                                    <input type="file" name="profile_image_2"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['profile_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                                    <p class="text-muted small">( Please save file name as the Credit name )</p>
                                                    Uploaded File: 
                                                    <?php if($row->profile_image_2): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->profile_image_2)); ?>"><?php echo e($row->profile_image_2); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>

                                                    <?php $__errorArgs = ['profile_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                
                                                </div>
                                            </div>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Have you been associated with Serendipity Arts in the past ? </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <select class="form-control form-control-lg form-control-solid selectpicker" name="has_serendipity_arts" tabindex="null" onchange="serendipityArtsChangePress(this)">
                                                <option value="">Select</option>
                                                <option value="Yes" <?php echo e(old('has_serendipity_arts') == 'Yes' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'Yes') ? 'selected' : ''); ?>>Yes</option>
                                                <option value="No" <?php echo e(old('has_serendipity_arts') == 'No' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'No') ? 'selected' : ''); ?>>No</option>
                                            </select>

                                            <?php $__errorArgs = ['has_serendipity_arts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 has-year" style="display: <?php echo e(old('has_serendipity_arts') == 'Yes' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'Yes') ? '' : 'none'); ?>;">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Year</label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <select class="form-control form-control-lg form-control-solid selectpicker" name="year[]" id="year" tabindex="null" multiple="">
                                                <option value="">Select Year</option>
                                                <?php if( isset($years) && count($years)): ?>
                                                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                       <option <?php echo e(in_array($year, old('year', $row->year ?? [] )) ? 'selected' : ''); ?> value="<?php echo e($year); ?>"><?php echo e($year); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>

                                            <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Link with videos of your work <i>(If any)</i> </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="other_link" value="<?php echo e(old('other_link') ? old('other_link') :( isset($row->other_link) ? $row->other_link : '')); ?>" class="form-control form-control-lg form-control-solid"  placeholder="Enter Link with videos of your work"/>
                                            <?php $__errorArgs = ['other_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-12">
                                    <div class="form-group row validated">
                                        <div class="col-lg-3 col-md-3 col-sm-12">
                                            &nbsp;
                                        </div>
                                        <div class="col-form-label col-lg-9 col-md-9 col-sm-12">
                                            <div class="checkbox-inline">
                                                <label class="checkbox">
                                                    <input type="checkbox" name="terms" value="1" required="" />
                                                    <span></span>
                                                    <?php echo e(env('FORM_CONSENT', 'I Accept Terms & Conditions')); ?>

                                                </label>
                                            </div>

                                            <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!--end::Body-->

                        <div class="card-footer">
                            <div class="row">
                                <?php if(\Auth::user()->is_freeze == 0): ?>
                                <div class="col-lg-4"></div>
                                <div class="col-lg-4 text-center">
                                    <button type="submit" class="theme-btn mt-0 mb-0">Update</button>
                                </div>
                                <?php else: ?>
                                    <div class="col-lg-12">
                                        <p class="text-center text-danger small italic">Your account has been freeze by admin hence you are not able to update any of details.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end::Card-->
            </div>
            <!--end::Content-->
        </div>
        <!--end::Education-->
    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    

    function serendipityArtsChangePress(_this){

        if($(_this).val() == 'Yes'){
            $(".has-year").show();
        } else {

            $(".has-year").hide();
        }
    }

    function samAsPermanentFun(_this){

        if($(_this).is(':checked')){
            $(".current_address_wrapper").hide();
        } else {

            $(".current_address_wrapper").show();
        }
    }

    function getStates(_this, source_id, target_id, title = '', selectedId = 0) {
        
        var country_id = $('#'+source_id).val();

        if(country_id){
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('states')); ?>/" + country_id,
                datatype: 'json',
                success: function (response) {
                    if(response?.status){
                        var options = '<option value="">Select '+title+'</option>';
                        if(response.data.length) {
                            for (var i = 0; i < response.data.length; i++) {

                                var _selected = '';

                                if(selectedId == response.data[i].id){

                                    _selected = 'selected';
                                }

                                options += '<option '+_selected+' value="'+response.data[i].id+'">'+response.data[i].state_name+'</option>';
                            }

                            $("#"+target_id).html(options);
                            $("#"+target_id).selectpicker('refresh');

                            if(selectedId){
                                getCities(null, 'pa_state_id', 'pa_city_id', 'State', <?php echo old( 'pa_city_id', $row->pa_city_id ?? 0 )?>);
                            }
                        }
                    }
                }
            });
        } else {
            $("#"+target_id).html('<option value="">Select '+title+'</option>');
            $("#"+target_id).selectpicker('refresh');
        }
    }

    function getCities(_this, source_id, target_id, title = '', selectedId = 0) {

        var state_id = $('#'+source_id).val();
        if (state_id){
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('cities')); ?>/" + state_id,
                datatype: 'json',
                success: function (response) {
                    if(response?.status){
                        var options = '<option value="">Select '+title+'</option>';
                        if(response.data.length){
                            for (var i = 0; i < response.data.length; i++) {

                                var _selected = '';

                                if(selectedId == response.data[i].id){

                                    _selected = 'selected';
                                }

                                options += '<option '+_selected+' value="'+response.data[i].id+'">'+response.data[i].city_name+'</option>';
                            }

                            $("#"+target_id).html(options);
                            $("#"+target_id).selectpicker('refresh');
                        }
                    }
                }
            });
        } else {
            $("#"+target_id).html('<option value="">Select '+title+'</option>');
            $("#"+target_id).selectpicker('refresh');
        }
    }

    function getProjects(_this, selectedId = 0) {
        var years = $('#year').val();

        if(years){
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('projects')); ?>/?year=" + years,
                datatype: 'json',
                success: function (response) {
                    if(response?.status){
                        var options = '<option value="">Select Project</option>';
                        if(response.data.length) {
                            for (var i = 0; i < response.data.length; i++) {

                                var _selected = '';

                                if(selectedId == response.data[i].id){

                                    _selected = 'selected';
                                }

                                options += '<option '+_selected+' value="'+response.data[i].id+'">'+response.data[i].name+'</option>';
                            }

                            $("#project_id").html(options);
                            $("#project_id").selectpicker('refresh');
                        }
                    }
                }
            });
        } else {
            $("#project_id").html('<option value="">Select Project</option>');
            $("#project_id").selectpicker('refresh');
        }
    }

    function checkOtherCountry(_this){

        if($(_this).val() == '2'){
            $(".state-wrapper").hide();
            $("#pa_state_id").val('');
            $("#pa_state_id").selectpicker('refresh');

            $(".city-wrapper").hide();
            $("#pa_city_id").val('');
            $("#pa_city_id").selectpicker('refresh');

            $(".pa-country-other").show();
        } else {

            $(".state-wrapper").show();
            $(".city-wrapper").show();
            // $(".pa-city-other").show();
            $(".pa-country-other").hide();
        }

        $("#pa_city_id").trigger('onchange');
        // checkOtherCity($("#pa_city_id").html(), 'pa-city-other');

    }

    function checkOtherCity(_this, selector = ''){

        if($(_this).val() == '7934'){
            $("." + selector).show();
        } else {

            $("." + selector).hide();
        }
    }
    
    $(document).ready(function(){
        
        getStates(null, 'pa_country_id', 'pa_state_id', 'State', <?php echo old( 'pa_state_id', $row->pa_state_id ?? 0 )?>);

        getProjects(null, <?php echo old( 'project_id', $row->project_id ?? 0 )?>);
    });
    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\system\wamp64\www\saf-artist\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>