<?php $__env->startComponent('mail::message'); ?>

Dear <?php echo e($user->name); ?>,

	We are pleased to confirm your registration with us. <br>
	Requesting you to take some time to fill the form using the login credentials are as below.

<?php $__env->startComponent('mail::table'); ?>
<table>
	<tr><td>User Name: </td><td><?php echo e($user->email ?? ''); ?> </td></tr>
	<tr><td>Password: </td><td><?php echo e(\Helper::decrypt($user->password_plane ?? '')); ?> </td></tr>
</table>
<?php echo $__env->renderComponent(); ?>

You can also click on this link to access the form.<br>
<a href="http://artist.serendipityarts.org/login">http://artist.serendipityarts.org/login</a><br>


We are happy to have you on board,<br>
Team Serendipity Arts
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/emails/registration/index.blade.php ENDPATH**/ ?>