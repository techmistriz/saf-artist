<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
	.radio {
		display: -webkit-box;
	}

	.image-input {
	    margin-right: 10px;
	}

</style>
<div class="row">
    <div class="col-md-12">
        
        <div class="card card-custom gutter-b">
            <div class="card-header">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(isset($row) && !empty($row) ? 'Edit' : 'Add'); ?> <?php echo e($moduleConfig['moduleTitle']); ?></h3>
                </div>
            </div>
            
            <div class="card-body">
                <div class="row">

                	<div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Are you registring for group </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control form-control-lg form-control-custom selectpicker" name="reg_for_group" tabindex="null" >
                                    <option value="">Select</option>
                                    <option <?php echo e(old('reg_for_group', $row->reg_for_group ?? '') == 'Yes' ? 'selected' : ''); ?> value="Yes">Yes</option>
                                    <option <?php echo e(old('reg_for_group', $row->reg_for_group ?? '') == 'No' ? 'selected' : ''); ?> value="No">No</option>
                                </select>
                                <?php $__errorArgs = ['reg_for_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Category </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select name="category_id" id="category_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Select Category</option>

                                    <?php if($categories->count()): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>" <?php echo e(old('category_id', $row->category_id ?? 0) == $value->id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Artist Type</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select name="artist_type_id" id="artist_type_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['artist_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Select Artist Type</option>

                                    <?php if($artistTypes->count()): ?>
                                        <?php $__currentLoopData = $artistTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>" <?php echo e(old('artist_type_id', $row->artist_type_id ?? 0) == $value->id ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                                <?php $__errorArgs = ['artist_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Name of Curators </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select name="curator_name" id="curator_name" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['curator_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">Select Curator</option>

                                    <?php if($curators->count()): ?>
                                        <?php $__currentLoopData = $curators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->name); ?>" <?php echo e(old('curator_name', $row->curator_name ?? '') == $value->name ? 'selected' : ''); ?>><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </select>
                                <?php $__errorArgs = ['curator_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Project Name </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control form-control-lg form-control-solid selectpicker" name="project_id" tabindex="null" >
                                    <option value="">Select</option>
                                    <?php if($projects->count()): ?>
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(old('project_id', $row->project_id ?? 0) == $value->id ? 'selected' : ''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Full Name </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="name" value="<?php echo e(old('name') ? old('name') : ( isset($row->name) ? $row->name : '')); ?>" class="form-control" placeholder="Enter Full Name"/>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">DOB </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">

                            	<div class="input-group date">
									<input type="text" name="dob" value="<?php echo e(old('dob') ? old('dob') : ( isset($row->dob) ? $row->dob : '')); ?>" class="form-control kt_datepicker" placeholder="Enter DOB" autocomplete="new dob" readonly />

									<?php $__errorArgs = ['vip_seats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

									<div class="input-group-append">
										<span class="input-group-text">
											<i class="la la-calendar-check-o"></i>
										</span>
									</div>
								</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Contact </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" oninput="this.value=this.value.replace(/[^0-9]/, '')" name="contact" value="<?php echo e(old('contact') ? old('contact') :( isset($row->contact) ? $row->contact : '')); ?>" class="form-control"  minlength="10" maxlength="10"  placeholder="Enter Contact"/>
                                <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Email </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="email" value="<?php echo e(old('email') ? old('email') : ( isset($row->email) ? $row->email : '')); ?>" class="form-control" placeholder="Enter Email"/>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Organisation/ Foundation/ Trust you are associated with (if any)</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="organisation" value="<?php echo e(old('organisation') ? old('organisation') :( isset($row->organisation) ? $row->organisation : '')); ?>" class="form-control "   placeholder="Enter Name of the Artisan"/>
                                <?php $__errorArgs = ['organisation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Address </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <textarea class="form-control no-summernote-editor" name="permanent_address" id="permanent_address" placeholder="Enter Address" require><?php echo e(old('permanent_address') ? old('permanent_address') : ( isset($row->permanent_address) ? $row->permanent_address : '')); ?></textarea>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
			                	
                	<div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Country </label>
                            	<div class="col-lg-9 col-md-9 col-sm-12">
                                <select name="pa_country_id" id="pa_country_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['pa_country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="getStates(this, 'pa_country_id', 'pa_state_id', 'State'); checkOtherCountry(this)">
			                    	<option value="">Select Country</option>

			                    	<?php if($countries->count()): ?>
		                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                                   	<option value="<?php echo e($country->id); ?>" <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == $country->id ? 'selected' : ''); ?>><?php echo e($country->country_name); ?></option>
		                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                            <?php endif; ?>

			                    </select>
                                <?php $__errorArgs = ['pa_country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6 pa-country-other" style="display: <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == 2 ? '' : 'none'); ?>">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Country - Other </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">

                                <input type="text" name="pa_country_other" value="<?php echo e(old('pa_country_other', $row->pa_country_other ?? '')); ?>" class="form-control" placeholder="Enter Country - Other" />

                                <?php $__errorArgs = ['pa_country_other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-6 state-wrapper" style="display: <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == 2 ? 'none' : ''); ?>">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">State </label>
                            	<div class="col-lg-9 col-md-9 col-sm-12">
                                
                                <select name="pa_state_id" id="pa_state_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['pa_state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="getCities(this, 'pa_state_id', 'pa_city_id', 'City')">
			                    	<option value="">Select State</option>

			                    </select>

                                <?php $__errorArgs = ['pa_state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                	
                	<div class="col-6 state-wrapper" style="display: <?php echo e(old('pa_country_id', $row->pa_country_id ?? 0) == 2 ? 'none' : ''); ?>">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">City</label>
                            	<div class="col-lg-9 col-md-9 col-sm-12">
                               
                               	<select name="pa_city_id" id="pa_city_id" class="form-control form-control-lg form-control-custom selectpicker <?php $__errorArgs = ['pa_city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-live-search="true" onchange="checkOtherCity(this, 'pa-city-other')">
			                    	<option value="">Select City</option>

			                    </select>

                                <?php $__errorArgs = ['pa_city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6 pa-city-other" style="display: <?php echo e(old('pa_city_id', $row->pa_city_id ?? 0) == 7934 ? '' : 'none'); ?>">
				        <div class="form-group row validated">
				            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">City - Other </label>
				            <div class="col-lg-9 col-md-9 col-sm-12">

				                <input type="text" name="pa_city_other" value="<?php echo e(old('pa_city_other', $row->pa_city_other ?? '')); ?>" class="form-control" placeholder="Enter City - Other" />

				                <?php $__errorArgs = ['pa_city_other'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				            </div>
				        </div>
				    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Pincode </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="pa_pincode" value="<?php echo e(old('pa_pincode') ? old('pa_pincode') :( isset($row->pa_pincode) ? $row->pa_pincode : '')); ?>" class="form-control" minlength="6" maxlength="6"  placeholder="Enter Pincode"/>
                                <?php $__errorArgs = ['pa_pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Stage Name <i>(If Any)</i></label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <textarea class="form-control no-summernote-editor" name="stage_name" id="stage_name" placeholder="Enter Stage Name"><?php echo e(old('stage_name') ? old('stage_name') : ( isset($row->stage_name) ? $row->stage_name : '')); ?></textarea>
                                <?php $__errorArgs = ['stage_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Artist Bio</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <textarea class="form-control no-summernote-editor" name="artist_bio" id="artist_bio" placeholder="Enter Artist Bio"><?php echo e(old('artist_bio') ? old('artist_bio') : ( isset($row->artist_bio) ? $row->artist_bio : '')); ?></textarea>
                                <?php $__errorArgs = ['artist_bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Instagram URL </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="instagram_url" value="<?php echo e(old('instagram_url') ? old('instagram_url') :( isset($row->instagram_url) ? $row->instagram_url : '')); ?>" class="form-control"   placeholder="Enter Instagram URL"/>
                                <?php $__errorArgs = ['instagram_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Facebook URL </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="facebook_url" value="<?php echo e(old('facebook_url') ? old('facebook_url') :( isset($row->facebook_url) ? $row->facebook_url : '')); ?>" class="form-control"   placeholder="Enter Facebook URL"/>
                                <?php $__errorArgs = ['facebook_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Linkdin URL </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="linkdin_url" value="<?php echo e(old('linkdin_url') ? old('linkdin_url') :( isset($row->linkdin_url) ? $row->linkdin_url : '')); ?>" class="form-control"   placeholder="Enter Linkdin URL"/>
                                <?php $__errorArgs = ['linkdin_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Twitter URL </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="twitter_url" value="<?php echo e(old('twitter_url') ? old('twitter_url') :( isset($row->twitter_url) ? $row->twitter_url : '')); ?>" class="form-control" placeholder="Enter Twitter URL"/>
                                <?php $__errorArgs = ['twitter_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                	<div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Website <i>(If Any)</i> </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="website" value="<?php echo e(old('website') ? old('website') :( isset($row->website) ? $row->website : '')); ?>" class="form-control"   placeholder="Enter Website"/>
                                <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                	<div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Please upload 3 high resolution images of your practice. </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                            
                                <div class="row pb-5">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        
                                        <input type="file" name="practice_image_1"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['practice_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                        <p class="text-muted small">( 5 MB to 10MB and 300 dpi )</p>
                                        
                                        Uploaded File: 
                                        <?php if(isset($row->practice_image_1) && !empty($row->practice_image_1)): ?>
                                            <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_1)); ?>"><?php echo e($row->practice_image_1); ?></a>
                                        <?php else: ?>
                                        N/A
                                        <?php endif; ?>

                                        <?php $__errorArgs = ['practice_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    </div>
                                </div>
                                <div class="row pb-5">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        
                                        <input type="file" name="practice_image_2"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['practice_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                        <p class="text-muted small">( 5 MB to 10MB and 300 dpi )</p>
                                        Uploaded File: 
                                        <?php if(isset($row->practice_image_2) && !empty($row->practice_image_2)): ?>
                                            <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_2)); ?>"><?php echo e($row->practice_image_2); ?></a>
                                        <?php else: ?>
                                        N/A
                                        <?php endif; ?>

                                        <?php $__errorArgs = ['practice_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    </div>
                                </div>

                                <div class="row pb-5">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        
                                        <input type="file" name="practice_image_3"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['practice_image_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                        <p class="text-muted small">( 5 MB to 10MB and 300 dpi )</p>
                                        Uploaded File: 
                                        <?php if(isset($row->practice_image_3) && !empty($row->practice_image_3)): ?>
                                            <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_3)); ?>"><?php echo e($row->practice_image_3); ?></a>
                                        <?php else: ?>
                                        N/A
                                        <?php endif; ?>

                                        <?php $__errorArgs = ['practice_image_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    </div>
                                </div>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Please upload 2 high resolution profile images. </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                            
                                <div class="row pb-5">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        
                                        <input type="file" name="profile_image_1"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['profile_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                        <p class="text-muted small">( Please save file name as the Credit name )</p>
                                        Uploaded File: 
                                        <?php if(isset($row->profile_image_1) && !empty($row->profile_image_1)): ?>
                                            <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->profile_image_1)); ?>"><?php echo e($row->profile_image_1); ?></a>
                                        <?php else: ?>
                                        N/A
                                        <?php endif; ?>

                                        <?php $__errorArgs = ['profile_image_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    </div>
                                </div>

                                <div class="row pb-5">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        
                                        <input type="file" name="profile_image_2"  class="form-control form-control-lg form-control-solid <?php $__errorArgs = ['profile_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                        <p class="text-muted small">( Please save file name as the Credit name )</p>
                                        Uploaded File: 
                                        <?php if(isset($row->profile_image_2) && !empty($row->profile_image_2)): ?>
                                            <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->profile_image_2)); ?>"><?php echo e($row->profile_image_2); ?></a>
                                        <?php else: ?>
                                        N/A
                                        <?php endif; ?>

                                        <?php $__errorArgs = ['profile_image_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                    </div>
                                </div>
                            
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                	<div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Have you been associated with Serendipity Arts in the past ? </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control selectpicker" name="has_serendipity_arts" tabindex="null"   onchange="serendipityArtsChangePress(this)">
                                    <option value="">Select</option>
                                    <option value="Yes" <?php echo e(old('has_serendipity_arts') == 'Yes' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'Yes') ? 'selected' : ''); ?>>Yes</option>
                                    <option value="No" <?php echo e(old('has_serendipity_arts') == 'No' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'No') ? 'selected' : ''); ?>>No</option>
                                </select>

                                <?php $__errorArgs = ['has_serendipity_arts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6 has-year" style="display: <?php echo e(old('has_serendipity_arts') == 'Yes' || (isset($row->has_serendipity_arts) && $row->has_serendipity_arts == 'Yes') ? '' : 'none'); ?>;">
                        <div class="form-group row validated">
                        	<label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Year</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control form-control-lg form-control-custom selectpicker" name="year[]" id="year" tabindex="null" multiple="">
                                    <option value="">Select</option>
                                    <?php if( isset($years) && count($years)): ?>
                                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(!empty(old('year')) && old('year') == $year ? 'selected' : ( isset($row->year) && $row->year == $year ? 'selected' : '' )); ?> value="<?php echo e($year); ?>"><?php echo e($year); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row">
                	<div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Link with videos of your work </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="other_link" value="<?php echo e(old('other_link') ? old('other_link') :( isset($row->other_link) ? $row->other_link : '')); ?>" class="form-control"  placeholder="Enter Link with videos of your work"/>
                                <?php $__errorArgs = ['other_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Password </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="password" name="password" value="" class="form-control" placeholder="Enter Password" autocomplete="new-password" />
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Confirm Password </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="password" name="password_confirm" value="" class="form-control" placeholder="Enter Confirm Password" autocomplete="new password_confirm" />
                                <?php $__errorArgs = ['password_confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4 text-center">
                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                        <a class="btn btn-light-danger" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">

	function serendipityArtsChangePress(_this){

		if($(_this).val() == 'Yes'){
			$(".has-year").show();
		} else {

			$(".has-year").hide();
		}
	}

	function samAsPermanentFun(_this){

		if($(_this).is(':checked')){
			$(".current_address_wrapper").hide();
		} else {

			$(".current_address_wrapper").show();
		}
	}

	function getStates(_this, source_id, target_id, title = '', selectedId = 0) {
	    var country_id = $('#'+source_id).val();

	    if(country_id){
		    $.ajax({
				type: "GET",
				url: "<?php echo e(url('states')); ?>/" + country_id,
				datatype: 'json',
				success: function (response) {
					if(response?.status){
						var options = '<option value="">Select '+title+'</option>';
						if(response.data.length) {
							for (var i = 0; i < response.data.length; i++) {

								var _selected = '';

								if(selectedId == response.data[i].id){

									_selected = 'selected';
								}

								options += '<option '+_selected+' value="'+response.data[i].id+'">'+response.data[i].state_name+'</option>';
							}

							$("#"+target_id).html(options);
							$("#"+target_id).selectpicker('refresh');

							getCities(null, 'pa_state_id', 'pa_city_id', 'State', <?php echo old( 'pa_city_id', $row->pa_city_id ?? 0 )?>);
						}
					}
				}
			});
	    } else {
	    	$("#"+target_id).html('<option value="">Select '+title+'</option>');
	    	$("#"+target_id).selectpicker('refresh');
	    }
    }

    function getCities(_this, source_id, target_id, title = '', selectedId = 0) {

	    var state_id = $('#'+source_id).val();
	    if (state_id){
		    $.ajax({
				type: "GET",
				url: "<?php echo e(url('cities')); ?>/" + state_id,
				datatype: 'json',
				success: function (response) {
					if(response?.status){
						var options = '<option value="">Select '+title+'</option>';
						if(response.data.length){
							for (var i = 0; i < response.data.length; i++) {

								var _selected = '';

								if(selectedId == response.data[i].id){

									_selected = 'selected';
								}

								options += '<option '+_selected+' value="'+response.data[i].id+'">'+response.data[i].city_name+'</option>';
							}

							$("#"+target_id).html(options);
							$("#"+target_id).selectpicker('refresh');
						}
					}
				}
			});
	    } else {
	    	$("#"+target_id).html('<option value="">Select '+title+'</option>');
	    	$("#"+target_id).selectpicker('refresh');
	    }
    }

    function getProjects(_this, selectedId = 0) {
        var years = $('#year').val();

        if(years){
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('projects')); ?>/?year=" + years,
                datatype: 'json',
                success: function (response) {
                    if(response?.status){
                        var options = '<option value="">Select Project</option>';
                        if(response.data.length) {
                            for (var i = 0; i < response.data.length; i++) {

                                var _selected = '';

                                if(selectedId == response.data[i].id){

                                    _selected = 'selected';
                                }

                                options += '<option '+_selected+' value="'+response.data[i].id+'">'+response.data[i].name+'</option>';
                            }

                            $("#project_id").html(options);
                            $("#project_id").selectpicker('refresh');
                        }
                    }
                }
            });
        } else {
            $("#project_id").html('<option value="">Select Project</option>');
            $("#project_id").selectpicker('refresh');
        }
    }

    function checkOtherCountry(_this){

        if($(_this).val() == '2'){
            $(".state-wrapper").hide();
            $("#pa_state_id").val('');
            $("#pa_state_id").selectpicker('refresh');

            $(".city-wrapper").hide();
            $("#pa_city_id").val('');
            $("#pa_city_id").selectpicker('refresh');

            $(".pa-country-other").show();
        } else {

            $(".state-wrapper").show();
            $(".city-wrapper").show();
            // $(".pa-city-other").show();
            $(".pa-country-other").hide();
        }

        $("#pa_city_id").trigger('onchange');
        // checkOtherCity($("#pa_city_id").html(), 'pa-city-other');

    }

    function checkOtherCity(_this, selector = ''){

		if($(_this).val() == '7934'){
			$("." + selector).show();
		} else {

			$("." + selector).hide();
		}
	}

 	$(document).ready(function(){
		
		getStates(null, 'pa_country_id', 'pa_state_id', 'State', <?php echo old( 'pa_state_id', $row->pa_state_id ?? 0 )?>);

        getProjects(null, <?php echo old( 'project_id', $row->project_id ?? 0 )?>);

    });



</script>
<?php $__env->stopPush(); ?><?php /**PATH D:\system\wamp64\www\saf-artist\resources\views/admin/user/forms/form.blade.php ENDPATH**/ ?>