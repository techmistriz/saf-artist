

<?php $__env->startSection('content'); ?>


<section class="saf-venuepage">
	<div class="container">
		<div class="row pb-3">
			<div class="col-md-12">
				<h1 class="main-title">Venues</h1>
				<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt consectetur adipiscing.</p> 
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<?php if($venues->count()): ?>
        			<?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="latestvenue-item">
						<div class="row">
							<div class="col-md-6">
								<h3 class="title"><?php echo e($value->title); ?></h3>
								<p class="location"><?php echo e($value->google_map_url); ?></p>
								<div class="desc-block">
									<div class="icon">
										<img src="<?php echo e(url('/image/aguad-jail.jpg')); ?>">
									</div>

									<div class="desc">
										<div class="short-desc"><?php echo e($value->short_description); ?>

										</div>

										<a href="<?php echo e(route('programs', ['venue' => $value->id])); ?>" class="link-btn">View programmes &LongRightArrow;</a>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<img src="<?php echo e(url('uploads/vanues/').'/'.$value->featured_image); ?>" alt="" class="venueimg">
							</div>
						</div>
					</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        	<?php endif; ?>

		<!-- 		<div class="latestvenue-item">
					<div class="row">
						<div class="col-md-6">
							<h3 class="title">Old GMC Building</h3>
							<p class="location">Location: Lorem ipsum dolor sit amet, consectetur.</p>
							<div class="desc-block">
								<div class="icon">
									<img src="<?php echo e(url('/image/ART-PARK.jpg')); ?>">
								</div>

								<div class="desc">
									<div class="short-desc">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
										incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
										exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
										irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
										pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
										deserunt mollit anim id est laborum.
									</div>

									<a href="#" class="link-btn">View programmes &LongRightArrow;</a>
								</div>	
							</div>
						</div>
						<div class="col-md-6">
							<img src="<?php echo e(url('/image/old-gmc-building.jpg')); ?>" alt="" class="venueimg">
						</div>
					</div>
				</div>


				<div class="latestvenue-item">
					<div class="row">
						<div class="col-md-6">
							<h3 class="title">Santa Monica Jetty</h3>
							<p class="location">Location: Lorem ipsum dolor sit amet, consectetur.</p>
							<div class="desc-block">
								<div class="icon">
									<img src="<?php echo e(url('/image/aguad-jail.jpg')); ?>">
								</div>

								<div class="desc">
									<div class="short-desc">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
										incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
										exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
										irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
										pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
										deserunt mollit anim id est laborum.
									</div>

									<a href="#" class="link-btn">View programmes &LongRightArrow;</a>
								</div>	
							</div>
						</div>
						<div class="col-md-6">
							<img src="<?php echo e(url('/image/sanat-monica-jetty.jpg')); ?>" alt="" class="venueimg">
						</div>
					</div>
				</div>



				<div class="latestvenue-item">
					<div class="row">
						<div class="col-md-6">
							<h3 class="title">Old GMC Building</h3>
							<p class="location">Location: Lorem ipsum dolor sit amet, consectetur.</p>
							<div class="desc-block">
								<div class="icon">
									<img src="<?php echo e(url('/image/ART-PARK.jpg')); ?>">
								</div>

								<div class="desc">
									<div class="short-desc">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
										incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
										exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
										irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
										pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
										deserunt mollit anim id est laborum.
									</div>

									<a href="#" class="link-btn">View programmes &LongRightArrow;</a>
								</div>	
							</div>
						</div>
						<div class="col-md-6">
							<img src="<?php echo e(url('/image/old-gmc-building.jpg')); ?>" alt="" class="venueimg">
						</div>
					</div>
				</div> -->




			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/frontend/venues.blade.php ENDPATH**/ ?>