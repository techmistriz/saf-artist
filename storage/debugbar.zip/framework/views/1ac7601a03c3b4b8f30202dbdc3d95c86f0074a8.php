

<?php $__env->startSection('content'); ?>

<center>

    <section class="cntform">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="logo-sa">
                        <img src="<?php echo e(url('/image/Logo-SVG.svg')); ?>" alt="Image"/>
                    </div>
                </div>
            </div>


            <div class="row justify-content-center">
                <div class="col-md-10">
                    <form class="form-sa" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="tab-1">
                            <h4 class="title"><span class="bagde">1</span>Fill Your Details</h4>

                            <div class="form-group">
                                <input type="text" class="regfield" name="name" id="name" placeholder="Full Name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <div class="gndr-block">
                                    <input type="radio" id="male" name="gender" value="male">
                                    <label for="male">Male</label><br>
                                    <input type="radio" id="female" name="gender" value="female">
                                    <label for="female">Female</label><br>
                                    <input type="radio" id="others" name="gender" value="others">
                                    <label for="others">Others</label>
                                </div>
                            </div>

                            <div class="row">
                            <div class="form-group col-md-3">
                                <input type="number" class="regfield" name="number" id="number" placeholder="Age">
                            </div>

                            <div class="form-group col-md-3">
                                <input type="date" class="regfield" name="date" id="date" placeholder="DOB">
                                <div class="datelabel">D.O.B</div>
                            </div>

                            <div class="form-group col-md-3">
                                <input type="text" class="regfield" name="contact" id="conatct" placeholder="Contact Number">
                            </div>

                            <div class="form-group col-md-3">
                                <input type="email" class="regfield" name="email" id="email" placeholder="Email Address">
                                <!--<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>-->
                                <!--    <span class="invalid-feedback" role="alert">-->
                                <!--        <strong><?php echo e($message); ?></strong>-->
                                <!--    </span>-->
                                <!--<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>-->
                            </div>
                            <!--<div class="form-group">-->
                            <!--    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">-->
                            <!--</div>-->
                            <!--<div class="form-group">-->
                            <!--    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">-->
                            <!--</div>-->
                            
                            </div>

                            
                            <div class="form-group">
                                <textarea class="regfield" name="permanentaddress" id="permanentaddress" placeholder="Permanent Address"></textarea>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-3">
                                    <input type="text" name="percity" id="percity" placeholder="City">
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" name="perstate" id="perstate" placeholder="State">
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" name="percountry" id="percountry" placeholder="Country">
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" name="percode" id="percode" placeholder="Pincode">
                                </div>
                            </div>

                            <div class="form-group">
                                <textarea class="regfield" name="currentaddress" id="currentaddress" placeholder="Current Address (Optional)"></textarea>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-3">
                                    <input type="text" name="curcity" id="curcity" placeholder="City">
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" name="curstate" id="curstate" placeholder="State">
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" name="curcountry" id="curcountry" placeholder="Country">
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="text" name="curcode" id="curcode" placeholder="Pincode">
                                </div>
                            </div>
                            

                            <div class="row">
                            <div class="form-group col-md-6">
                                <select class="regfield" name="addressproof" id="addressproof">
                                    <option value="_none" disabled="disabled" selected="selected">Address Proof</option>
                                    <option value="1">Aadhaar Card</option>
                                    <option value="2">Driving Licesence (DL)</option>
                                    <option value="3">Passport</option>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <input type="file" name="filedoc" id="filedoc" >
                            </div>
                            </div>

                            <div class="form-group">
                                <input type="text" class="regfield" name="stagename" id="stagename" placeholder="Stage Name( If Any )">
                            </div>


                            <div class="form-group">
                                <textarea class="regfield" name="artistbio" id="artistbio" placeholder="Artist bio"></textarea>
                            </div>

                            <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" class="regfield" name="instauser" id="instauser" placeholder="Instagram Username">
                            </div>

                            <div class="form-group col-md-6">
                                <input type="url" class="regfield" name="instaurl" id="instaurl" placeholder="Instagram URL">
                            </div>
                            </div>

                            <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" class="regfield" name="fbuser" id="fbauser" placeholder="Facebook Username">
                            </div>

                            <div class="form-group col-md-6">
                                <input type="url" class="regfield" name="fburl" id="fburl" placeholder="Facebook URL">
                            </div>
                            </div>

                            <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" class="regfield" name="linkedinuser" id="linkedinuser" placeholder="Linkedin Username">
                            </div>

                            <div class="form-group col-md-6">
                                <input type="url" class="regfield" name="linkedinurl" id="linkedinurl" placeholder="Linkedin URL">
                            </div>
                            </div>

                            <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" class="regfield" name="twitteruser" id="twitteruser" placeholder="Twitter Username">
                            </div>

                            <div class="form-group col-md-6">
                                <input type="url" class="regfield" name="twitterurl" id="twitterurl" placeholder="Twitter URL">
                            </div>
                            </div>


                            <div class="form-group">
                                <input type="url" class="regfield" name="website" id="website" placeholder="www.yourwebsite.com">
                            </div>

                            

                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="practiceimg">Please upload 3 high resolution images of your practice.</label>
                                    <input type="file" id="practiceimg" name="practiceimg" multiple><br><br>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="profileimg">Please upload 2 high resolution profile images.</label>
                                    <input type="file" id="profileimg" name="profileimg" multiple><br><br>
                                </div>
                            </div>

                            <div class="form-group">
                                <select class="regfield" name="associatedwith" id="associatedwith">
                                    <option value="_none" disabled="disabled" selected="selected">Have you been associated with Serendipity Arts in the past ?</option>
                                    <option value="1">Yes</option>
                                    <option value="2">No</option>
                                </select>
                            </div>

                            <div id="ascwith">
                            <div class="row">
                                <div class="col-md-6">
                                    <select class="regfield" name="selectyear" id="selectyear">
                                        <option value="_none" disabled="disabled" selected="selected">Select year</option>
                                        <option value="1">2016</option>
                                        <option value="2">2017</option>
                                        <option value="3">2018</option>
                                        <option value="4">2019</option>
                                        <option value="5">2022</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                <input type="text" class="regfield" name="projectname" id="projectname" placeholder="Project Name">
                                </div>
                            </div>
                            </div>

                            <div class="row">
                            <div class="form-group col-md-6">
                                <input type="url" class="regfield" name="relevantlink" id="relevantlink" placeholder="Any Other Relevant Links">
                            </div>

                            <div class="form-group col-md-6">
                                <select class="regfield" name="category" id="category">
                                    <option value="_none" disabled="disabled" selected="selected">Select Category</option>
                                    <option value="1">Accessibility</option>
                                    <option value="2">Craft</option>
                                    <option value="3">Culinary Arts</option>
                                    <option value="4">Dance </option>
                                    <option value="5">Exhibitions</option>
                                    <option value="6">Music</option>
                                    <option value="7">Photography</option>
                                    <option value="8">Talks</option>
                                    <option value="9">Theatre</option>
                                    <option value="10">Visual Arts</option>
                                    <option value="11">Special Project</option>
                                    <option value="12">Workshop</option>
                                </select>
                            </div>
                            </div>
                
                            <div class="action-btn">
                                <!--<button type="submit" class="btn btn-primary">-->
                                <!--    <?php echo e(__('Register')); ?>-->
                                <!--</button>-->
                                <a type="button" id="nextBtn1"> Next</a>
                            </div>  
                        </div>

                        <div class="tab-2 craft">
                                <h4 class="title"><span class="bagde">2</span>Fill Your Details</h4>
                                <input type="text" name="craft" id="craft" placeholder="Your Craft">
                                <div class="action-btn"><a type="button" id="prevBtn1"> &lt; Back </a>
                                <a type="button" id="nextBtn2">Next &gt; </a>
                                </div>  
                        </div>

                        <div class="tab-2 singing">
                            <h4 class="title"><span class="bagde">2</span>Fill Your Details</h4>
                            <input type="text" name="singing" id="singing" placeholder="Your Singing">
                            <div class="action-btn"><a type="button" id="prevBtn1"> &lt; Back </a>
                                <a type="button" id="nextBtn2">Next &gt; </a>
                            </div>  
                        </div>

                        <div class="tab-3">
                            <h4 class="title"><span class="bagde">3</span>Fill Your Details</h4>
                            <input type="text" name="name" placeholder="Your Name">
                            
                            <div class="action-btn">
                                <a type="button" id="prevBtn2"> &lt; Back </a>
                                <input type="submit"  id="regcomp" value="Sumit">
                            </div>  
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </section>



</center>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\artist\resources\views/home-1.blade.php ENDPATH**/ ?>