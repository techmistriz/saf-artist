<?php echo e($slot); ?>

<?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>