<?php echo e($slot); ?>

<?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>