

<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column-fluid">
    <div class="container">

        <div class="row">
		    <div class="col-md-12">
		        
		        <div class="card card-custom gutter-b">
		            <div class="card-header">
		                <div class="card-title">
		                    <h3 class="card-label">Show <?php echo e($moduleConfig['moduleTitle']); ?> Account Details</h3>
		                </div>
		            </div>
		            
		            <div class="card-body">
		                <div class="row">
		                    
		                    <div class="col-9">
		                        
		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Full Name: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">
		                            	<label class="col-form-label text-lg-right"><?php echo e($row->name); ?></label>
		                                
		                            </div>
		                        </div>

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Address Proof Image </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">
		                                
		                            	<div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

		                            		<?php if(isset($row->address_proof_image) && !empty($row->address_proof_image)): ?>
												<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->address_proof_image)); ?>)"></div>

												

		                            		<?php else: ?>
		                            			<div class="image-input-wrapper"></div>
		                            		<?php endif; ?>
										</div>

										<div class="">
											Uploaded File: 
			                                <?php if($row->address_proof_image): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->address_proof_image)); ?>"><?php echo e($row->address_proof_image); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
										</div>
		                            
		                            </div>
		                        </div>

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Account Number: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->account_number); ?></label>
		                            
		                            </div>
		                        </div> 


		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Bank Holder Number: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->bank_holder_number); ?></label>
		                            
		                            </div>
		                        </div> 
		                        

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Bank Name: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->bank_name); ?></label>
		                            
		                            </div>
		                        </div> 

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Branch Address: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->branch_address); ?></label>
		                            
		                            </div>
		                        </div> 

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">IFSC Code: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->ifsc_code); ?></label>
		                            
		                            </div>
		                        </div> 

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Cancel Cheque Image: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">
		                                
		                            	<div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

		                            		<?php if(isset($row->cancel_cheque_image) && !empty($row->cancel_cheque_image)): ?>
												<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->cancel_cheque_image)); ?>)"></div>

												

		                            		<?php else: ?>
		                            			<div class="image-input-wrapper"></div>
		                            		<?php endif; ?>
										</div>

										<div class="">
											Uploaded File: 
			                                <?php if($row->cancel_cheque_image): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->cancel_cheque_image)); ?>"><?php echo e($row->cancel_cheque_image); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
										</div>
		                            
		                            </div>
		                        </div>


		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Pancard Number: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->pancard_number); ?></label>
		                            
		                            </div>
		                        </div> 

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Pancard Image: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">
		                                
		                            	<div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

		                            		<?php if(isset($row->pancard_image) && !empty($row->pancard_image)): ?>
												<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->pancard_image)); ?>)"></div>

												

		                            		<?php else: ?>
		                            			<div class="image-input-wrapper"></div>
		                            		<?php endif; ?>
										</div>

										<div class="">
											Uploaded File: 
			                                <?php if($row->pancard_image): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->pancard_image)); ?>"><?php echo e($row->pancard_image); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
										</div>
		                            
		                            </div>
		                        </div>


		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">GST Number: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->has_gst_number); ?></label>
		                            	
		                            </div>
		                        </div> 

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Gst Certificate: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<div class="">
											Uploaded File: 
			                                <?php if($row->gst_certificate_file): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->gst_certificate_file)); ?>"><?php echo e($row->gst_certificate_file); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
										</div>

		                            </div>
		                        </div> 

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">HSN/SAC Code: </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<label class="col-form-label text-lg-right"><?php echo e($row->hsn_sac_code); ?></label>
		                            
		                            </div>
		                        </div> 

		                        <div class="form-group row validated">
		                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Menu/Inventory List Of The Products To Be Sold (With MRP And Quantity): </label>
		                            <div class="col-lg-9 col-md-9 col-sm-12">

		                            	<div class="">
											Uploaded File: 
			                                <?php if($row->product_inventory_file): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->product_inventory_file)); ?>"><?php echo e($row->product_inventory_file); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
										</div>
										
		                            </div>
		                        </div> 
		                        

		                    </div>
		                </div>
		            </div>

		            <div class="card-footer">
		                <div class="row">
		                    <div class="col-lg-4"></div>
		                    <div class="col-lg-4 text-center">
		                        <a class="btn btn-primary" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Back</a>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>

		</div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\artist\resources\views/admin/user/show.blade.php ENDPATH**/ ?>