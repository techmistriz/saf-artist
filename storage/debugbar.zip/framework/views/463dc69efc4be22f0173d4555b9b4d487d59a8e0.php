
<?php $__env->startSection('content'); ?>
<section class="saf-loginpage">
	<div class="container">
	    <div class="row justify-content-center">
	        <div class="col-md-6">
	            <div class="pb-13 pt-lg-0 pt-5 text-center">
                    <h3 class="font-weight-bolder text-dark font-size-h4 font-size-h1-lg">Forgotten Password ?</h3>
                    <span class="text-muted font-weight-bold font-size-h4">Enter your email to reset your password
                </div>

            	<form class="loginfrm" method="POST" action="<?php echo e(route('password.email')); ?>">
            		
		            <?php if(session('status')): ?>
	                    <div class="alert alert-success" role="alert">
	                        <?php echo e(session('status')); ?>

	                    </div>
	                <?php endif; ?>
                    <?php echo csrf_field(); ?>
	                <div class="form-group">
	                    <label for="email">Email</label>
	                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

	                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                        <span class="invalid-feedback" role="alert">
	                            <strong><?php echo e($message); ?></strong>
	                        </span>
	                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	                </div>
	           
	                <div class="form-group cntr">
	                    <input type="submit" value="Submit &LongRightArrow;">
	                </div>
	            </form>
	        </div>
	    </div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>