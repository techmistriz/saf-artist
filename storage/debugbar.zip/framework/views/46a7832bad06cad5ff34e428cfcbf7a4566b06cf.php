<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-12">
        
        <div class="card card-custom gutter-b">
            <div class="card-header">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(isset($row) && !empty($row) ? 'Edit' : 'Add'); ?> <?php echo e($moduleConfig['moduleTitle']); ?></h3>
                </div>
            </div>
            
            <div class="card-body">
                <div class="row">
                    
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Name</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="name" value="<?php echo e(old('name') ? old('name') :( isset($row->name) ? $row->name : '')); ?>" class="form-control" required placeholder="Enter Name"/>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Amount </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" oninput="this.value=this.value.replace(/[^0-9.]/, '')" name="amount" value="<?php echo e(old('amount') ? old('amount') : ( isset($row->amount) ? $row->amount : '')); ?>" class="form-control" <?php echo e(isset($row->amount) ? '':'required'); ?> placeholder="Enter Amount" autocomplete="new amount" />
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Event Date </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">

                            	<div class="input-group date">
									<input type="text" name="event_date" value="<?php echo e(old('event_date') ? old('event_date') : ( isset($row->event_date) ? $row->event_date : '')); ?>" class="form-control kt_datepicker" <?php echo e(isset($row->event_date) ? '':'required'); ?> placeholder="Enter Event Date" autocomplete="new event_date" readonly />

									<?php $__errorArgs = ['vip_seats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

									<div class="input-group-append">
										<span class="input-group-text">
											<i class="la la-calendar-check-o"></i>
										</span>
									</div>
								</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Event From Time </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">

                            	<div class="input-group timepicker">
									<input type="text" name="from_time" value="<?php echo e(old('from_time') ? old('from_time') : ( isset($row->from_time) ? $row->from_time : '')); ?>" class="form-control kt_timepicker" <?php echo e(isset($row->from_time) ? '':'required'); ?> placeholder="Enter Event From Time" autocomplete="new from_time" readonly />
	                                <?php $__errorArgs = ['from_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									<div class="input-group-append">
										<span class="input-group-text">
											<i class="la la-clock-o"></i>
										</span>
									</div>
								</div>
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Event To Time </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">

                            	<div class="input-group timepicker">
									<input type="text" name="to_time" value="<?php echo e(old('to_time') ? old('to_time') : ( isset($row->to_time) ? $row->to_time : '')); ?>" class="form-control kt_timepicker" <?php echo e(isset($row->to_time) ? '':'required'); ?> placeholder="Enter Event To Time" autocomplete="new to_time" readonly/>
	                                <?php $__errorArgs = ['to_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
	                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
	                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									<div class="input-group-append">
										<span class="input-group-text">
											<i class="la la-clock-o"></i>
										</span>
									</div>
								</div>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Total Seats </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input  type="number" min="0" max="9999999" name="total_seats" value="<?php echo e(old('total_seats') ? old('total_seats') : ( isset($row->total_seats) ? $row->total_seats : '')); ?>" class="form-control" <?php echo e(isset($row->total_seats) ? '':'required'); ?> placeholder="Enter Total Seat" autocomplete="new total_seats" />
                                <?php $__errorArgs = ['total_seats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">VIP Seats </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input  type="number" min="0" max="9999999" name="vip_seats" value="<?php echo e(old('vip_seats') ? old('vip_seats') : ( isset($row->vip_seats) ? $row->vip_seats : '')); ?>" class="form-control" <?php echo e(isset($row->vip_seats) ? '':'required'); ?> placeholder="Enter Total Seat" autocomplete="new vip_seats" />
                                <?php $__errorArgs = ['vip_seats'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left"> Category </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control selectpicker" name="category_id" tabindex="null" required data-live-search="true">
                                    <option value="" data-slug="">Select</option>
                                    <?php if($categories->count()): ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(!empty(old('category_id')) && old('category_id') == $value->id ? 'selected' : ( isset($row->category_id) && $row->category_id == $value->id ? 'selected' : '' )); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left"> Venue </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control selectpicker" name="venue_id" tabindex="null" required data-live-search="true">
                                    <option value="" data-slug="">Select</option>
                                    <?php if($venues->count()): ?>
                                        <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(!empty(old('venue_id')) && old('venue_id') == $value->id ? 'selected' : ( isset($row->venue_id) && $row->venue_id == $value->id ? 'selected' : '' )); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->title); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php $__errorArgs = ['venue_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left"> Discipline </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control selectpicker" name="discipline_id" tabindex="null" required data-live-search="true">
                                    <option value="" data-slug="">Select</option>
                                    <?php if($disciplines->count()): ?>
                                        <?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(!empty(old('discipline_id')) && old('discipline_id') == $value->id ? 'selected' : ( isset($row->discipline_id) && $row->discipline_id == $value->id ? 'selected' : '' )); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php $__errorArgs = ['discipline_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left"> Curator </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control selectpicker" name="curator_id" tabindex="null" required data-live-search="true">
                                    <option value="" data-slug="">Select</option>
                                    <?php if($curators->count()): ?>
                                        <?php $__currentLoopData = $curators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(!empty(old('curator_id')) && old('curator_id') == $value->id ? 'selected' : ( isset($row->curator_id) && $row->curator_id == $value->id ? 'selected' : '' )); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php $__errorArgs = ['curator_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left"> Program Tags </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select multiple="" class="form-control selectpicker" name="program_tag_ids[]" tabindex="null" required data-live-search="true">
                                    <option value="" data-slug="">Select</option>
                                    <?php if($program_tags->count()): ?>
                                        <?php $__currentLoopData = $program_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(!empty(old('program_tag_ids')) && in_array($value->id, old('program_tag_ids')) ? 'selected' : ( isset($row->program_tag_ids) && in_array($value->id, $row->program_tag_ids) ? 'selected' : '' )); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php $__errorArgs = ['program_tag_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6">

                        <div class="form-group row validated">

                        	<label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Status</label>
							<div class="col-3">
								<span class="switch switch-icon">
									<label>
										<input type="checkbox" value="1" name="status" <?php echo e((old('status') == '1' || (!isset($row->status) || empty($row->status)) ) ? 'checked' : ( isset($row->status) && $row->status == '1' ? 'checked' : '')); ?> />
										<span></span>
									</label>
								</span>
							</div>
                        </div>
                    </div>

                    
                </div>

                <div class="row">
                	<div class="col-12">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Description </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                            	<textarea class="form-control summernote-editor" name="description" id="description" placeholder="Enter Description" require><?php echo e(old('description') ? old('description') : ( isset($row->description) ? $row->description : '')); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-12">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Disclaimer </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                            	<textarea class="form-control summernote-editor" name="disclaimer" id="disclaimer" placeholder="Enter Disclaimer" required><?php echo e(old('disclaimer') ? old('disclaimer') : ( isset($row->disclaimer) ? $row->disclaimer : '')); ?></textarea>
                                <?php $__errorArgs = ['disclaimer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-12">

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Program Image </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                
                            	<div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

                            		<?php if(isset($row->program_image) && !empty($row->program_image)): ?>
										<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/programs/'.$row->program_image)); ?>)"></div>
                            		<?php else: ?>
                            			<div class="image-input-wrapper program_image_base64"></div>
                            		<?php endif; ?>

									<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
										<i class="fa fa-pen icon-sm text-muted"></i>
										<input type="file" name="program_image" accept=".png, .jpg, .jpeg"/>
										<input type="hidden" name="program_image_remove"/>
									</label>

									<?php if(isset($row->program_image) && !empty($row->program_image)): ?>
										<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
											<i class="ki ki-bold-close icon-xs text-muted"></i>
										</span>
                            		<?php else: ?>
										<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
											<i class="ki ki-bold-close icon-xs text-muted"></i>
										</span>
                            		<?php endif; ?>
								</div>

                                <?php $__errorArgs = ['program_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4 text-center">
                        <button type="submit" class="btn btn-light-primary mr-2">Submit</button>
                        <a class="btn btn-primary" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
    var avatar4 = new KTImageInput('program_image_1');

	avatar4.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	avatar4.on('change', function(imageInput) {

		// swal.fire({
		// 	title: 'Image successfully uploaded !',
		// 	type: 'error',
		// 	buttonsStyling: false,
		// 	confirmButtonText: 'Okay!',
		// 	confirmButtonClass: 'btn btn-primary font-weight-bold'
		// });
		
	});

	avatar4.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/admin/program/forms/form.blade.php ENDPATH**/ ?>