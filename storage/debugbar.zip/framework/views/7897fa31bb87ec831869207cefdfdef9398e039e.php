<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\system\wamp64\www\saf-artist\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>