<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-12">
        
        <div class="card card-custom gutter-b">
            <div class="card-header">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(isset($row) && !empty($row) ? 'Edit' : 'Add'); ?> <?php echo e($moduleConfig['moduleTitle']); ?></h3>
                </div>
            </div>
            
            <div class="card-body">
                <div class="row">                    
                    <div class="col-12">
                                                
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Question:</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="question" value="<?php echo e(old('question', $row->question ?? '')); ?>" class="form-control" required placeholder="Enter question"/>
                                <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Answer:</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                
                                <textarea name="answer" class="form-control" required placeholder="Enter answer" ><?php echo e(old('answer', $row->answer ?? '')); ?></textarea>
                                <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row validated">
                        	<label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Status:</label>
							<div class="col-3">
								<span class="switch switch-icon">
									<label>
										<input type="checkbox" value="1" name="status" <?php echo e(old('status', $row->status ?? 1) == '1' ? 'checked' : ''); ?> />
										<span></span>
									</label>
								</span>
							</div>
                        </div>
                    </div>                    
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4 text-center">
                        <button type="submit" class="btn btn-light-primary mr-2">Submit</button>
                        <a class="btn btn-light-danger" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopPush(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/admin/faq/forms/form.blade.php ENDPATH**/ ?>