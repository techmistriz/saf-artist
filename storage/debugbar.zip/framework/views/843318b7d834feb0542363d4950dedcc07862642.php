<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>SAF</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!--end::Fonts-->
	<!--begin::Global Theme Styles(used by all pages)-->
	<link href="<?php echo e(asset('plugins/global/plugins.bundlef552.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('css/style.bundlef552.css')); ?>" rel="stylesheet" type="text/css" />
	<!--end::Global Theme Styles-->

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.8/slick.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.8/slick-theme.min.css">

	<!--begin::Layout Themes(used by all pages)-->
	<link href="<?php echo e(asset('css/themes/layout/header/base/lightf552.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('css/themes/layout/header/menu/lightf552.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('css/themes/layout/brand/darkf552.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('css/themes/layout/aside/darkf552.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(asset('css/login-1.css')); ?>" rel="stylesheet" type="text/css" />

	<?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
    <div id="app">
	    <div id="myNav" class="overlay">
	        <div class="overlay-content">
	            <div class="container">
	                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
	                <li><a href="<?php echo e(route('venues')); ?>">Venues</a></li>
	                <li><a href="<?php echo e(route('curators')); ?>">Curators</a></li>
	                <li><a href="<?php echo e(route('vibes')); ?>">Vibes</a></li>
	                <li><a href="<?php echo e(route('programs')); ?>">Programs</a></li>
	                <li><a href="<?php echo e(route('exhibitions')); ?>">Exhibitions</a></li>
	                <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
	                <li><a href="<?php echo e(route('register')); ?>">Register now</a></li>
	                <li><a href="<?php echo e(route('contact')); ?>">Contact us</a></li>
	            </div>
	        </div>
	    </div>

	    <header class="main-header">
	        <div class="container">
	            <div class="row">
	                <div class="col-md-7">
	                     <div class="left-block">
	                        <div class="logo">
	                            <a href="<?php echo url('/') ?>">Serendipity arts festival 2023</a>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-md-5">
	                    <div class="right-block">
	                    	<?php if(Auth::check()): ?>
								<li class="drop-btn">Hi, <?php echo e(Auth::user()->name ?? 'N/A'); ?> ↓
									<ul class="dropdowncstm">
										<li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
									 	<li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form-header').submit();"> <?php echo e(__('Logout')); ?></a> </li>
					                  	<form id="logout-form-header" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
						                    <?php echo e(csrf_field()); ?>

					                  	</form>

									</ul>
								</li>
                        	<?php else: ?> 
                        		<li class="lgn-btn"><a href="<?php echo e(route('login')); ?>">login</a></li>
							<?php endif; ?>
	                        <a class="nav-toggle"><span></span></a>
	                    </div>
	                </div>
	            </div>
	        </div>
		</header>

	    <main class="">
	        <?php echo $__env->yieldContent('content'); ?>
	    </main>
	        
	    <footer class="main-footer">
	        <div class="container">
	            <div class="row">

	                <div class="col-md-3">
	                    <div class="footer-logo">
	                        <img src="<?php echo e(url('/image/logo-footer.png')); ?>" width="80%">
	                    </div>
	                </div>

	                <div class="col-md-3">
	                    <div class="quick-links">
	                        <h4>Quick Links</h4>
	                        <ul class="footer-menus">
	                        	<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
				                <li><a href="<?php echo e(route('venues')); ?>">Venues</a></li>
				                <li><a href="<?php echo e(route('curators')); ?>">Curators</a></li>
				                <li><a href="<?php echo e(route('programs')); ?>">Programs</a></li>
				                <li><a href="<?php echo e(route('exhibitions')); ?>">Exhibitions</a></li>
				                <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
				                <li><a href="<?php echo e(route('register')); ?>">Register now</a></li>
				                <li><a href="<?php echo e(route('contact')); ?>">Contact us</a></li>
				                <li><a href="<?php echo e(route('vibes')); ?>">Vibes</a></li>
				                <li><a href="<?php echo e(route('media.stories')); ?>">Media</a></li>
	                        </ul>
	                    </div>
	                </div>

	                <div class="col-md-3">
	                    <div class="contact-details">
	                        <h4>Get in Touch</h4>
	                        <a href="#"><i class="fa fa-envelope"></i> info@serendipityarts.org</a>
	                        <a href="#"><i class="fa fa-phone"></i> info@serendipityarts.org</a>
	                        <a href="#"><i class="fa fa-map-marker-alt"></i> C-340 Chetna Marg, Block C, Defence Colony, New Delhi-110024</a>
	                    </div>
	                </div>

	                <div class="col-md-3">
	                    <div class="social-icon">
	                        <h4>Follow us on</h4>
	                        <a href="#"><i class="fab fa-instagram"></i></a>
	                        <a href="#"><i class="fab fa-facebook-f"></i></a>
	                        <a href="#"><i class="fab fa-twitter"></i></a>
	                    </div>
	                </div>

	            </div>
	        </div>
	    </footer>

	</div>
</body>

<script>var KTAppSettings = { "breakpoints": { "sm": 576, "md": 768, "lg": 992, "xl": 1200, "xxl": 1400 }, "colors": { "theme": { "base": { "white": "#ffffff", "primary": "#3699FF", "secondary": "#E5EAEE", "success": "#1BC5BD", "info": "#8950FC", "warning": "#FFA800", "danger": "#F64E60", "light": "#E4E6EF", "dark": "#181C32" }, "light": { "white": "#ffffff", "primary": "#E1F0FF", "secondary": "#EBEDF3", "success": "#C9F7F5", "info": "#EEE5FF", "warning": "#FFF4DE", "danger": "#FFE2E5", "light": "#F3F6F9", "dark": "#D6D6E0" }, "inverse": { "white": "#ffffff", "primary": "#ffffff", "secondary": "#3F4254", "success": "#ffffff", "info": "#ffffff", "warning": "#ffffff", "danger": "#ffffff", "light": "#464E5F", "dark": "#ffffff" } }, "gray": { "gray-100": "#F3F6F9", "gray-200": "#EBEDF3", "gray-300": "#E4E6EF", "gray-400": "#D1D3E0", "gray-500": "#B5B5C3", "gray-600": "#7E8299", "gray-700": "#5E6278", "gray-800": "#3F4254", "gray-900": "#181C32" } }, "font-family": "Poppins" };</script>
<script src="<?php echo e(asset('plugins/global/plugins.bundlef552.js?v=7.1.8')); ?>"></script>
<!-- <script src="<?php echo e(asset('js/scripts.bundlef552.js?v=7.1.8')); ?>"></script> -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.5.9/slick.min.js"></script>
<script src="<?php echo e(asset('js/mymain.js')); ?>"></script>   

<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/layouts/app.blade.php ENDPATH**/ ?>