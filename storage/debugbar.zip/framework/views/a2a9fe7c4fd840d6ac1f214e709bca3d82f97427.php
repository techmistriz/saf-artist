
<?php $__env->startSection('content'); ?>

<section class="saf-mediapage">
	<div class="container">
		<div class="row pb-3">
			<div class="col-md-12">
	            <h1 class="main-title">Media</h1>
	            <p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt consectetur adipiscing.</p> 
	        </div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="saf-media">
					<div class="row">
						<?php if($medias->count()): ?>
		        			<?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4">
									<div class="media-item">
										<img src="<?php echo e(url('uploads/medias/').'/'.$value->featured_image); ?>" alt="" width="100%">

										<h3 class="title"><?php echo e($value->name); ?></h3>
										<p class="short-desc"><?php echo e($value->short_description); ?></p>
										<a href="javascript:void(0)" data-toggle="modal" data-target="#knowMoreModal<?php echo e($value->id); ?>" class="link-btn">Know More &LongRightArrow;</a>
									</div>
								</div>

								<div class="modal fade" id="knowMoreModal<?php echo e($value->id); ?>" tabindex="-1" role="dialog" aria-labelledby="knowMoreModalLabel<?php echo e($value->id); ?>" aria-hidden="true">
			                        <div class="modal-dialog" role="document">
			                            <div class="modal-content">
			                                <div class="modal-header">
			                                    <h5 class="modal-title" id="knowMoreModalLabel<?php echo e($value->id); ?>">Information</h5>
			                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			                                        <i aria-hidden="true" class="ki ki-close"></i>
			                                    </button>
			                                </div>
			                                <div class="modal-body">
			                                    <?php echo $value->description; ?>

			                                </div>
			                                <div class="modal-footer">
			                                    <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Close</button>
			                                    <a href="<?php echo e($value->external_link); ?>" target="_blank" class="btn btn-primary font-weight-bold external-link-btn">Visit Site</a>
			                                </div>
			                            </div>
			                        </div>
			                    </div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        	<?php endif; ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/frontend/media.blade.php ENDPATH**/ ?>