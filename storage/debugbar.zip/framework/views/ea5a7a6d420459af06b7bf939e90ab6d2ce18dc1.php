<?php $__env->startSection('content'); ?>
<style type="text/css">
	.image-input {
	    margin-right: 10px;
	}
	.image-input .image-input-wrapper {
	    width: 85px;
	    height: 85px;
	}
	.bootstrap-select>.dropdown-toggle.btn-light, .bootstrap-select>.dropdown-toggle.btn-secondary {
	    height: calc(1.5em + 1.65rem + 2px);
	    padding: 0.825rem 1.42rem;
	    font-size: 1.08rem;
	    line-height: 1.5;
	    border-radius: 0.42rem;
        background-color: #f3f6f9 !important;
    	border-color: #f3f6f9 !important;
	}
</style>
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class=" container ">
        <!--begin::Education-->
        <div class="d-flex flex-row">
            <!--begin::Aside-->
            <?php echo $__env->make('frontend/includes/aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--end::Aside-->
            <!--begin::Content-->
            <div class="flex-row-fluid ml-lg-8">

            	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            	
                <!--begin::Card-->
                <div class="card card-custom gutter-bs">

                    <!--Begin::Header-->
                    <div class="card-header">

                    	

		                <div class="card-title">
		                    <h3 class="card-label">Project Category Details</h3>
		                </div>
		            </div>
                    <!--end::Header-->

                    <!--Begin::Body-->
                    <div class="card-body">

                    	<?php echo $__env->make('frontend/category_details/category_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <!--end::Body-->

                	<form action="<?php echo e(route('update.category.details')); ?>" method="POST" enctype="multipart/form-data">
			            <input type="hidden" name="_method" value="PUT">
			            <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
			            <?php echo e(csrf_field()); ?>


	                    <!--Begin::Body-->
	                    <div class="card-body">
			                <div class="row">
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Project Name </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid  selectpicker" name="project_id" tabindex="null" >
				                                <option value="">Select</option>
				                               	<?php if($projects->count()): ?>
				                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				                                       <option <?php echo e(!empty(old('project_id')) && old('project_id') == $project_id->id ? 'selected' : ( isset($row->project_id) && $row->project_id == $project_id->id ? 'selected' : '' )); ?> value="<?php echo e($project_id->id); ?>"><?php echo e($project_id->name); ?></option>

				                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                                <?php endif; ?>
				                            </select>
			                            </div>
			                        </div>
			                    </div>
			                     
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Number of people in your group </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
											<input type="text" name="no_of_people_in_group" oninput="this.value=this.value.replace(/[^0-9]/, '')" value="<?php echo e(old('no_of_people_in_group') ? old('no_of_people_in_group') : ( isset($row->no_of_people_in_group) ? $row->no_of_people_in_group : '')); ?>" class="form-control form-control-lg form-control-solid" <?php echo e(isset($row->no_of_people_in_group) ? '':''); ?> placeholder="Enter Details"/>

											<?php $__errorArgs = ['no_of_people_in_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Form / Genre </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
											<input type="text" name="form_genre" value="<?php echo e(old('form_genre') ? old('form_genre') : ( isset($row->form_genre) ? $row->form_genre : '')); ?>" class="form-control form-control-lg form-control-solid" placeholder="Enter Form / Genre"/>

											<?php $__errorArgs = ['form_genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Organisation/ Foundation/ Trust you are associated with(if any) </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="organisation" value="<?php echo e(old('organisation') ? old('organisation') :( isset($row->organisation) ? $row->organisation : '')); ?>" class="form-control form-control-lg form-control-solid" maxlength="15"  placeholder="Enter Organisation/ Foundation/ Trust you are associated with(if any)"/>
			                                <?php $__errorArgs = ['organisation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Synopsis/ Description of the performance</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="synopsis_description_of_the_performance" value="<?php echo e(old('synopsis_description_of_the_performance') ? old('synopsis_description_of_the_performance') :( isset($row->synopsis_description_of_the_performance) ? $row->synopsis_description_of_the_performance : '')); ?>" class="form-control form-control-lg form-control-solid" maxlength="15"  placeholder="Enter Synopsis/ Description of the performance"/>
			                                <?php $__errorArgs = ['synopsis_description_of_the_performance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Light designer needed</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="light_designer_needed" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <option value="Yes" <?php echo e(old('light_designer_needed', $row->light_designer_needed ?? '') == 'Yes' ? 'selected' : ''); ?>>Yes</option>

			                                    <option value="No" <?php echo e(old('light_designer_needed', $row->light_designer_needed ?? '') == 'No' ? 'selected' : ''); ?>>No</option>

			                                    <option value="Maybe" <?php echo e(old('light_designer_needed', $row->light_designer_needed ?? '') == 'Maybe' ? 'selected' : ''); ?>>Maybe</option>
			                                </select>

			                                <?php $__errorArgs = ['light_designer_needed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Sound designer needed</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="sound_designer_needed" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <option value="Yes" <?php echo e(old('sound_designer_needed', $row->sound_designer_needed ?? '') == 'Yes' ? 'selected' : ''); ?>>Yes</option>

			                                    <option value="No" <?php echo e(old('sound_designer_needed', $row->sound_designer_needed ?? '') == 'No' ? 'selected' : ''); ?>>No</option>

			                                    <option value="Maybe" <?php echo e(old('sound_designer_needed', $row->sound_designer_needed ?? '') == 'Maybe' ? 'selected' : ''); ?>>Maybe</option>
			                                </select>

			                                <?php $__errorArgs = ['sound_designer_needed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">IPRS licence required?</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="iprs_license_required" tabindex="null" >
			                                    <option value="">Select</option>
			                                    <option value="Yes" <?php echo e(old('iprs_license_required', $row->iprs_license_required ?? '') == 'Yes' ? 'selected' : ''); ?>>Yes</option>

			                                    <option value="No" <?php echo e(old('iprs_license_required', $row->iprs_license_required ?? '') == 'No' ? 'selected' : ''); ?>>No</option>

			                                    <option value="Maybe" <?php echo e(old('iprs_license_required', $row->iprs_license_required ?? '') == 'Maybe' ? 'selected' : ''); ?>>Maybe</option>
			                                    
			                                </select>

			                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Space and visual design requirements </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="space_visual_design_requirements" id="space_visual_design_requirements" placeholder="Enter Space and visual design requirements" require><?php echo e(old('space_visual_design_requirements') ? old('space_visual_design_requirements') : ( isset($row->space_visual_design_requirements) ? $row->space_visual_design_requirements : '')); ?></textarea>
			                                <?php $__errorArgs = ['space_visual_design_requirements'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>
			               
			                
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Tech Rider </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                            	<input type="file" name="tech_rider"  class="form-control form-control-lg form-control-solid  <?php $__errorArgs = ['tech_rider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
			                                Uploaded File: 
			                                <?php if($row->tech_rider): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->tech_rider)); ?>"><?php echo e($row->tech_rider); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
			                                <?php $__errorArgs = ['tech_rider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Are you part of any other project</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="has_part_of_other_project" tabindex="null" onchange="hasPartOfOtherProject(this)">
			                                    <option value="">Select</option>

			                                    <option value="Yes" <?php echo e(old('has_part_of_other_project', $row->has_part_of_other_project ?? '') == 'Yes' ? 'selected' : ''); ?>>Yes</option>
			                                    <option value="No" <?php echo e(old('has_part_of_other_project', $row->has_part_of_other_project ?? '') == 'No' ? 'selected' : ''); ?>>No</option>

			                                </select>

			                                <?php $__errorArgs = ['has_part_of_other_project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12 has-part-of-other-project" style="display: <?php echo e(old('has_part_of_other_project', $row->has_part_of_other_project ?? 'No') == 'Yes' ? '' : 'none'); ?>">

			                    	<div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Category of the project </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="other_project_category_id" id="other_project_category_id" tabindex="null" onchange="getProjects(this)">
	                                            <option value="">Select</option>
	                                           	<?php if($categories->count()): ?>
							                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							                           <option <?php echo e(old('other_project_category_id', $row->other_project_category_id ?? 0) == $value->id ? 'selected' : ''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

							                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							                    <?php endif; ?>
	                                        </select>
			                                <?php $__errorArgs = ['other_project_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>

			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Name of the project </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="other_project_id" id="other_project_id" tabindex="null" >
	                                            <option value="">Select</option>
	                                           	
	                                        </select>
			                                <?php $__errorArgs = ['other_project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
		                    </div>
			                
			            </div>
	                    <!--end::Body-->

	                    <div class="card-footer">
			                <div class="row">
			                	<?php if(\Auth::user()->is_freeze == 0): ?>
			                    <div class="col-lg-4"></div>
			                    <div class="col-lg-4 text-center">
			                        <button type="submit" class="theme-btn mt-0 mb-0">Update</button>
			                    </div>
			                    <?php else: ?>
			                    	<div class="col-lg-12">
			                    		<p class="text-center text-danger small italic">Your account has been freeze by admin hence you are not able to update any of details.</p>
			                    	</div>
			                    <?php endif; ?>
			                </div>
			            </div>
		            </form>

                </div>
                <!--end::Card-->
            </div>
            <!--end::Content-->
        </div>
        <!--end::Education-->
    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/frontend/category_details/dance/edit.blade.php ENDPATH**/ ?>