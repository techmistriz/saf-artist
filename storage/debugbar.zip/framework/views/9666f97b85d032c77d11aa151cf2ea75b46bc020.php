<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/vendor/mail/html/table.blade.php ENDPATH**/ ?>