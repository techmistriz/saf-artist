<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-md-12">
        
        <div class="card card-custom gutter-b">
            <div class="card-header">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(isset($row) && !empty($row) ? 'Edit' : 'Add'); ?> <?php echo e($moduleConfig['moduleTitle']); ?> For Role "<?php echo e($role->name); ?>"</h3>
                </div>
            </div>
            
            <div class="card-body">
                <table class="table">
                    <tr>
                        <th>Module Name</th>
                        <th>Access</th>
                    
                    </tr>
                    
                    <?php if($adminModules->count()): ?>
                        <?php $__currentLoopData = $adminModules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
                        <tr>
                            <td><?php echo e($value->name); ?>=><?php echo e($value->controller); ?> </td>
                            <td><div class="col-3"><span class="switch switch-icon"><label>
                            <input type="checkbox" value="<?php echo e($value->controller); ?>" name="permission_data[]" <?php echo e((in_array($value->controller, $row->permission_data) ? 'checked' : '')); ?> />
                            <span></span></label></span></div></td>                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </table>
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-4 text-center">
                        <button type="submit" class="btn btn-light-primary mr-2">Submit</button>
                        <a class="btn btn-primary" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    

</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/admin/permission/forms/form.blade.php ENDPATH**/ ?>