

<?php $__env->startSection('content'); ?>

<section class="intro-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="title">India's largest <span>multidisciplinary arts festival</span> is back for its 6<sup>th</sup> edition.</h1>
			</div>
		</div>
		<div class="row justify-content-end">
			<div class="col-md-6">
				<div class="desc">
					Experience the finest of exhibitions, performances, workshops, books, foodand so much more!
				</div>
				<div class="link-btn">
					<a href="#">book seats ⟶</a>
				</div>
				<div class="register">
					<a href="#">Register for free</a> for Serendipity Arts Festival and enable your visit to SAF'23
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="blue-btn">
				<div class="first-link">
					<ul>
						<li>#AccessibleAtSAF</li>
						<li>#ChildFriendlyAtSAF</li>
						<li>#ECOFriendlyAtSAF</li>
						<li>#SustainableAtSAF</li>
						<li>#AccessibleAtSAF</li>
						<li>#ChildFriendlyAtSAF</li>
						<li>#ECOFriendlyAtSAF</li>
						<li>#SustainableAtSAF</li>
					</ul>
				</div>
			</div>
		<div>
	</div>
<section>



<section class="aboutsaf-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="title">Serendipity Art Festival 2023 <span>Programming</span></h1>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">

			<div class="wrapper">
				<input class="radio" id="one" name="group" type="radio" checked>
				<input class="radio" id="two" name="group" type="radio">
				<input class="radio" id="three" name="group" type="radio">
				<input class="radio" id="four" name="group" type="radio">
				<div class="tabs">
					<label class="tab" id="one-tab" for="one">exhibitions</label>
					<div class="seprator-item"></div>
					<label class="tab" id="two-tab" for="two">performances</label>
					<label class="tab" id="three-tab" for="three">workshops</label>
					<div class="seprator-item"></div>
					<label class="tab" id="four-tab" for="four">talks</label>
				</div>

				<div class="panels">
					<div class="panel" id="one-panel">
						<div class="row">
							<div class="col-md-6">
								<div class="desc">
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
									laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
									architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
									sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione
									voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
									consectetur, adipisci velit.
								</div>
							</div>

							<div class="col-md-6">
								<img src="<?php echo e(url('/image/about-dummy.jpg')); ?>">
							</div>
						</div>
					</div>

					<div class="panel" id="two-panel">
						<div class="row">
							<div class="col-md-6">
								<div class="desc">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
								incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
								exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute 
								irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla 
								pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
								deserunt mollit anim id est laborum.
								</div>
							</div>

							<div class="col-md-6">
								<img src="<?php echo e(url('/image/dummy-venue.jpg')); ?>">
							</div>
						</div>
					</div>
					<div class="panel" id="three-panel">
						<div class="row">
							<div class="col-md-6">
								<div class="desc">
									Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
									laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
									architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas
									sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione
									voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet,
									consectetur, adipisci velit.
								</div>
							</div>

							<div class="col-md-6">
								<img src="<?php echo e(url('/image/dummy-program.jpg')); ?>">
							</div>
						</div>
					</div>
					<div class="panel" id="four-panel">
						<div class="row">
							<div class="col-md-6">
								<div class="desc">
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
								incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
								exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute 
								irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla 
								pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
								deserunt mollit anim id est laborum.
								</div>
							</div>

							<div class="col-md-6">
								<img src="<?php echo e(url('/image/exhibition-dummy.jpg')); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
</section>


<section class="tinytots-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="title"><span>Programming</span> for Tiny Tots</h1>
			</div>
		</div>

		<div class="row">
			<div class="col-md-4">
				<div class="tiny-card">
					<img src="<?php echo e(url('/image/tiny-dummy.jpg')); ?>" alt="">
					<h3 class="title">
						accelerate your creative process
					</h3>
					<p class="desg">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
						incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
						exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
					</p>
				</div>
			</div>
			<div class="col-md-4">
			     <div class="tiny-card">
					<img src="<?php echo e(url('/image/tiny-dummy.jpg')); ?>" alt="">
					<h3 class="title">
						accelerate your creative process
					</h3>
					<p class="desg">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
						incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
						exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
					</p>
				</div>
			</div>
			<div class="col-md-4">
			<div class="tiny-card">
					<img src="<?php echo e(url('/image/tiny-dummy.jpg')); ?>" alt="">
					<h3 class="title">
						accelerate your creative process
					</h3>
					<p class="desg">
						Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
						incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
						exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
					</p>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="insta-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="title"><span>Using our offical hastag</span> for a chance to be featured on our star wall</h1>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="insta-post">

				</div>
			</div>

		</div>

		
	</div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/home.blade.php ENDPATH**/ ?>