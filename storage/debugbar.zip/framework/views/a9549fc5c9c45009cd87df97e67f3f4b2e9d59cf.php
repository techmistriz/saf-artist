<div class="row">
    <div class="col-12">
        <h5 class="card-label">Ground Transport</h5><hr>
    </div>

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">airport transfer</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <select class="form-control form-control-lg form-control-solid selectpicker" name="airport_transfer" tabindex="null">
                    <option value="">Select</option>
                    <option value="Yes" <?php echo e(old('airport_transfer', $row->travelBoarding->airport_transfer ?? '') == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                    <option value="No" <?php echo e(old('airport_transfer', $row->travelBoarding->airport_transfer ?? '') == 'No' ? 'selected' : ''); ?>>No</option>
                </select>

                <?php $__errorArgs = ['airport_transfer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">airport drop required</label>
            <div class="col-lg-9 col-md-9 col-sm-12">

                <div class="input-group date">
                    <input type="text" name="airport_drop_required_date" value="<?php echo e(old('airport_drop_required_date', $row->travelBoarding->airport_drop_required_date ?? '')); ?>" class="form-control kt_datepicker" placeholder="Enter Details" readonly />

                    <?php $__errorArgs = ['airport_drop_required_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="input-group-append">
                        <span class="input-group-text">
                            <i class="la la-calendar-check-o"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">no. of dedicated cab required for the GROUP</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <input type="text" name="no_of_dedicated_cab" value="<?php echo e(old('no_of_dedicated_cab', $row->travelBoarding->no_of_dedicated_cab ?? '')); ?>" class="form-control" placeholder="Enter Details" />
                <?php $__errorArgs = ['no_of_dedicated_cab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>


    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">dedicated cab required - starting date </label>
            <div class="col-lg-9 col-md-9 col-sm-12">

                <div class="input-group date">
                    <input type="text" name="dedicated_cab_required_starting_date" value="<?php echo e(old('dedicated_cab_required_starting_date', $row->travelBoarding->dedicated_cab_required_starting_date ?? '')); ?>" class="form-control kt_datepicker" placeholder="Enter Details" readonly />

                    <?php $__errorArgs = ['dedicated_cab_required_starting_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="input-group-append">
                        <span class="input-group-text">
                            <i class="la la-calendar-check-o"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">dedicated cab required - end date</label>
            <div class="col-lg-9 col-md-9 col-sm-12">

                <div class="input-group date">
                    <input type="text" name="dedicated_cab_required_end_date" value="<?php echo e(old('dedicated_cab_required_end_date', $row->travelBoarding->dedicated_cab_required_end_date ?? '')); ?>" class="form-control kt_datepicker" placeholder="Enter Details" readonly />

                    <?php $__errorArgs = ['dedicated_cab_required_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="input-group-append">
                        <span class="input-group-text">
                            <i class="la la-calendar-check-o"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">group poc name</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <input type="text" name="group_poc_name" value="<?php echo e(old('group_poc_name', $row->travelBoarding->group_poc_name ?? '')); ?>" class="form-control" placeholder="Enter Details" />
                <?php $__errorArgs = ['group_poc_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">group poc whatsapp number</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <input type="text" name="group_poc_whatsapp_number" value="<?php echo e(old('group_poc_whatsapp_number', $row->travelBoarding->group_poc_whatsapp_number ?? '')); ?>" class="form-control" placeholder="Enter Details" />
                <?php $__errorArgs = ['group_poc_whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">artist remarks</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <textarea class="form-control no-summernote-editor" name="hotel_artist_remarks" id="hotel_artist_remarks" placeholder="Enter Details" require><?php echo e(old('hotel_artist_remarks', $row->travelBoarding->hotel_artist_remarks ?? '')); ?></textarea>
                <?php $__errorArgs = ['hotel_artist_remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            </div>
        </div>
    </div>

    <div class="col-6">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">poc remarks</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <textarea class="form-control no-summernote-editor" name="hotel_poc_remarks" id="hotel_poc_remarks" placeholder="Enter Details" require><?php echo e(old('hotel_poc_remarks', $row->travelBoarding->hotel_poc_remarks ?? '')); ?></textarea>
                <?php $__errorArgs = ['hotel_poc_remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            </div>
        </div>
    </div>

</div><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/admin/travel_boarding/forms/ground_transport_booking_form.blade.php ENDPATH**/ ?>