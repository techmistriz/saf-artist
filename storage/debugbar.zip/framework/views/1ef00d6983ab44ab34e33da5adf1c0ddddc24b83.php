

<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column-fluid">
    <div class="container">

        <div class="row">
		    <div class="col-md-12">
		        
		        <div class="card card-custom gutter-b">
		            <div class="card-header">
		                <div class="card-title">
		                    <h3 class="card-label"> <?php echo e($moduleConfig['moduleTitles'].' "'. $role[0]->name.'"'); ?></h3>
		                </div>
		            </div>
		            
		            <form method="POST" action="<?php echo e(route($moduleConfig['routes']['permissionRoute'])); ?>">
		            	<?php
			            	$row = json_decode($row);
		            		if (!empty($row[0])) {
		            			$id = $row[0]->id;		            			
	                        	$permission = json_decode($row[0]->permission_data)->module;
		            		}else{
		            			$id = '';
		            			$row[0] = [];
		            			$permission  = [];

		            		}
                        ?>
		            	<input type="hidden" name="role_id" value="<?php echo e($role_id); ?>">
		            	<input type="hidden" name="id" value="<?php echo e($id); ?>">
		            	<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		            	      <?php echo e(csrf_field()); ?>

			            <div class="card-body">
							<table class="table">
			            		<tr>
	                            	<th>Module Name</th>
	                               	<th>Access</th>
	                            
	                            </tr>
                            	
			            	 	<?php if($modules->count()): ?>
	                            	<?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		            		
		                            <tr>
		                            	<td><?php echo e($role->name); ?> </td>
		                               	<td><div class="col-3"><span class="switch switch-icon"><label>
										<input type="checkbox" value="<?php echo e($role->controller); ?>" name="modules[]" <?php echo e((in_array($role->id, $permission) ? 'checked' : '')); ?> />
										<span></span></label></span></div></td>                            
		                            </tr>
		                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        	<?php endif; ?>
		                    </table>
			            </div>

			            <div class="card-footer">
			                <div class="row">
			                    <div class="col-lg-4"></div>
			                    <div class="col-lg-4 text-center">
			                    	<button type="submit" class="btn btn-light-primary mr-2">Submit</button>
			                        <a class="btn btn-primary" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Back</a>
			                    </div>
			                </div>
			            </div>
		            </form>

		        </div>
		    </div>

		</div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/admin/permission/permission.blade.php ENDPATH**/ ?>