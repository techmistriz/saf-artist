

<?php $__env->startSection('content'); ?>

<h1>Edit Profile</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/frontend/accounts/profile/edit.blade.php ENDPATH**/ ?>