<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
	.radio {
		display: -webkit-box;
	}
</style>
<div class="row">
    <div class="col-md-12">
        
        <div class="card card-custom gutter-b">
            <div class="card-header">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(isset($row) && !empty($row) ? 'Edit' : 'Add'); ?> <?php echo e($moduleConfig['moduleTitle']); ?></h3>
                </div>
            </div>
            
            <div class="card-body">
                <div class="row">
                    
                    <div class="col-6">
                        
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right"> Role </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control selectpicker" name="role_id" tabindex="null" required>
                                    <option value="" data-slug="">Select</option>
                                    <?php if($roles->count()): ?>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <option <?php echo e(!empty(old('role_id')) && old('role_id') == $role->id ? 'selected' : ( isset($row->role_id) && $row->role_id == $role->id ? 'selected' : '' )); ?> value="<?php echo e($role->id); ?>" data-slug="<?php echo e($role->slug); ?>"><?php echo e($role->name); ?></option>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Full Name </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="name" value="<?php echo e(old('name') ? old('name') :( isset($row->name) ? $row->name : '')); ?>" class="form-control" required placeholder="Enter Full Name"/>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Gender </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                               
                               	<div class="radio-inline">
							        <label class="radio">
							            <input type="radio" name="gender" value="male" <?php echo e((old('gender') == 'male' || (!isset($row->gender) || empty($row->gender)) ) ? 'checked' : ( isset($row->gender) && $row->gender == 'male' ? 'checked' : '')); ?> />
							            <span></span>
							            Male
							        </label>
							        <label class="radio">
							            <input type="radio" name="gender" value="female" <?php echo e((old('gender') == 'female' ) ? 'checked' : ( isset($row->gender) && $row->gender == 'female' ? 'checked' : '')); ?> />
							            <span></span>
							            Female
							        </label>

							        <label class="radio">
							            <input type="radio" name="gender" value="others" <?php echo e((old('gender') == 'others' ) ? 'checked' : ( isset($row->gender) && $row->gender == 'others' ? 'checked' : '')); ?> />
							            <span></span>
							            Others
							        </label>
							        
							    </div>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Contact </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" oninput="this.value=this.value.replace(/[^0-9]/, '')" name="contact" value="<?php echo e(old('contact') ? old('contact') :( isset($row->contact) ? $row->contact : '')); ?>" class="form-control" maxlength="15" required placeholder="Enter Contact"/>
                                <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Country </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="country" value="<?php echo e(old('country') ? old('country') :( isset($row->country) ? $row->country : '')); ?>" class="form-control" maxlength="15" required placeholder="Enter Country"/>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">City </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="city" value="<?php echo e(old('city') ? old('city') :( isset($row->city) ? $row->city : '')); ?>" class="form-control" maxlength="15" required placeholder="Enter City"/>
                                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Interests </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                
                                <div class="checkbox-inline">

                                	<?php if($disciplines->count()): ?>
                                        <?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discipline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <label class="checkbox">
							                    <input type="checkbox" class="interest" name="interest[]" value="<?php echo e($discipline->id); ?>" <?php echo e(old('interest') && in_array($discipline->id, old('interest')) ? 'checked' : ( isset($row->interest) && in_array($discipline->id, $row->interest) ? 'checked' : '')); ?> />
							                    <span></span>
							                    <?php echo e($discipline->name ?? 'N/A'); ?>

							                </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <label class="checkbox">
					                    <input type="checkbox" onchange="allCheckClick(this)" />
					                    <span></span>
					                    All
					                </label>

					                
					                <!-- <label class="checkbox">
					                    <input type="checkbox" name="interest[]" value="2" />
					                    <span></span>
					                    Music
					                </label>
					                <label class="checkbox">
					                    <input type="checkbox" name="interest[]" value="3" />
					                    <span></span>
					                    Dance
					                </label>
					                <label class="checkbox">
					                    <input type="checkbox" name="interest[]" value="4" />
					                    <span></span>
					                    Theatre
					                </label>
					                <label class="checkbox">
					                    <input type="checkbox" name="interest[]" value="5" />
					                    <span></span>
					                    Photography
					                </label>
					                <label class="checkbox">
					                    <input type="checkbox" name="interest[]" value="6" />
					                    <span></span>
					                    Visual Arts
					                </label>
					                <label class="checkbox">
					                    <input type="checkbox" name="interest[]" value="7" />
					                    <span></span>
					                    Culinary Arts
					                </label> -->
					                
					                
					            </div>

                                <?php $__errorArgs = ['interests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Email </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="email" value="<?php echo e(old('email') ? old('email') : ( isset($row->email) ? $row->email : '')); ?>" class="form-control" required placeholder="Enter Email"/>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Password </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="password" name="password" value="" class="form-control" <?php echo e(isset($row->password) ? '':'required'); ?> placeholder="Enter Password" autocomplete="new password" />
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Confirm Password </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="password" name="password_confirm" value="" class="form-control" <?php echo e(isset($row->password) ? '':'required'); ?> placeholder="Enter Confirm Password" autocomplete="new password_confirm" />
                                <?php $__errorArgs = ['password_confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>

                        <div class="form-group row validated">

                        	<label class="col-form-label col-lg-3 col-sm-12 text-lg-right">Status</label>
							<div class="col-3">
								<span class="switch switch-icon">
									<label>
										<input type="checkbox" value="1" name="status" <?php echo e((old('status') == '1' || (!isset($row->status) || empty($row->status)) ) ? 'checked' : ( isset($row->status) && $row->status == '1' ? 'checked' : '')); ?> />
										<span></span>
									</label>
								</span>
							</div>
                        </div>

                        
                    </div>
                    
                </div>
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4 text-center">
                        <button type="submit" class="btn btn-light-primary mr-2">Submit</button>
                        <a class="btn btn-primary" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
    function allCheckClick(_this){
    	
    	if($(_this).is(':checked')){
    		$(".interest").prop('checked', true);
    	} else {

    		$(".interest").prop('checked', false);
    	}
    }

</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/admin/user/forms/form.blade.php ENDPATH**/ ?>