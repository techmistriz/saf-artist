<div class="row">
    <div class="col-12">
        <h5 class="card-label">Ground Transport</h5><hr>
    </div>

    <div class="col-12">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">group poc name</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <input type="text" name="group_poc_name" value="<?php echo e(old('group_poc_name', $row->travelBoarding->group_poc_name ?? '')); ?>" class="form-control form-control-solid form-control-lg" placeholder="Enter Details" />
                <?php $__errorArgs = ['group_poc_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">group poc whats app number</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <input type="text" name="group_poc_whatsapp_number" value="<?php echo e(old('group_poc_whatsapp_number', $row->travelBoarding->group_poc_whatsapp_number ?? '')); ?>" class="form-control form-control-solid form-control-lg" placeholder="Taxi/Driver details will be shared on this number" />
                <?php $__errorArgs = ['group_poc_whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="form-group row validated">
            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">artist remarks</label>
            <div class="col-lg-9 col-md-9 col-sm-12">
                <textarea class="form-control form-control-solid form-control-lg no-summernote-editor" name="ground_transport_artist_remarks" id="ground_transport_artist_remarks" placeholder="Enter Details"><?php echo e(old('ground_transport_artist_remarks', $row->travelBoarding->ground_transport_artist_remarks ?? '')); ?></textarea>
                <?php $__errorArgs = ['ground_transport_artist_remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            </div>
        </div>
    </div>

</div><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/frontend/travel_boarding_details/forms/ground_transport_booking_form.blade.php ENDPATH**/ ?>