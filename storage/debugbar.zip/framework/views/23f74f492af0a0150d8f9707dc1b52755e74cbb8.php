<?php $__env->startSection('content'); ?>
<style type="text/css">
	.image-input {
	    margin-right: 10px;
	}
	.image-input .image-input-wrapper {
	    width: 85px;
	    height: 85px;
	}
	.bootstrap-select>.dropdown-toggle.btn-light, .bootstrap-select>.dropdown-toggle.btn-secondary {
	    height: calc(1.5em + 1.65rem + 2px);
	    padding: 0.825rem 1.42rem;
	    font-size: 1.08rem;
	    line-height: 1.5;
	    border-radius: 0.42rem;
        background-color: #f3f6f9 !important;
    	border-color: #f3f6f9 !important;
	}
</style>
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class=" container ">
        <!--begin::Education-->
        <div class="d-flex flex-row">
            <!--begin::Aside-->
            <?php echo $__env->make('frontend/includes/aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--end::Aside-->
            <!--begin::Content-->
            <div class="flex-row-fluid ml-lg-8">

            	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            	
                <!--begin::Card-->
                <div class="card card-custom gutter-bs">

                    <!--Begin::Header-->
                    <div class="card-header">

                    	

		                <div class="card-title">
		                    <h3 class="card-label">Project Category Details</h3>
		                </div>
		            </div>
                    <!--end::Header-->

                    <!--Begin::Body-->
                    <div class="card-body">

                    	<?php echo $__env->make('frontend/category_details/category_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <!--end::Body-->

                	<form action="<?php echo e(route('update.category.details')); ?>" method="POST" enctype="multipart/form-data">
			            <input type="hidden" name="_method" value="PUT">
			            <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
			            <?php echo e(csrf_field()); ?>


	                    <!--Begin::Body-->
	                    <div class="card-body">
			                <div class="row">
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Project Name </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="project_id" tabindex="null" >
                                                <option value="">Select</option>
                                               	<?php if($projects->count()): ?>
                                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                       <option <?php echo e(old('project_id', $row->project_id ?? 0) == $value->id ? 'selected' : ''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
			                                <?php $__errorArgs = ['project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Organisation/ Foundation/ Trust you are associated with (if any)</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="organisation" value="<?php echo e(old('organisation') ? old('organisation') :( isset($row->organisation) ? $row->organisation : '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Details"/>
			                                <?php $__errorArgs = ['organisation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Name of the Artisan</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="name_of_the_artisan" value="<?php echo e(old('name_of_the_artisan') ? old('name_of_the_artisan') :( isset($row->name_of_the_artisan) ? $row->name_of_the_artisan : '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Details"/>
			                                <?php $__errorArgs = ['name_of_the_artisan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">About the Artisan </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">

			                            	<div class="input-group date">
												<textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="about_the_artisan" id="about_the_artisan" placeholder="Enter About the Artisan" ><?php echo e(old('about_the_artisan') ? old('about_the_artisan') : ( isset($row->about_the_artisan) ? $row->about_the_artisan : '')); ?></textarea>

												<?php $__errorArgs = ['form_genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
				                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
				                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

												
											</div>
			                            </div>
			                        </div>
			                    </div>
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Name of the Design Studio</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="name_of_the_design_studio" value="<?php echo e(old('name_of_the_design_studio') ? old('name_of_the_design_studio') :( isset($row->name_of_the_design_studio) ? $row->name_of_the_design_studio : '')); ?>" class="form-control form-control-lg form-control-solid" maxlength="15"  placeholder="Enter Name of the Design Studio"/>
			                                <?php $__errorArgs = ['name_of_the_design_studio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">About the Design Studio</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="about_the_design_studio" id="about_the_design_studio" placeholder="Enter About the Design Studio" ><?php echo e(old('about_the_design_studio') ? old('about_the_design_studio') : ( isset($row->about_the_design_studio) ? $row->about_the_design_studio : '')); ?></textarea>
			                                <?php $__errorArgs = ['about_the_design_studio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>
			                 
			                	<div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">About the Crafts </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="about_the_crafts" id="about_the_crafts" placeholder="Enter About the Crafts" ><?php echo e(old('about_the_crafts') ? old('about_the_crafts') : ( isset($row->about_the_crafts) ? $row->about_the_crafts : '')); ?></textarea>
			                                <?php $__errorArgs = ['biodata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">About the Director/Designers </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <textarea class="form-control form-control-lg form-control-solid no-summernote-editor" name="about_the_director" id="about_the_director" placeholder="Enter About the Director/Designers" ><?php echo e(old('about_the_director') ? old('about_the_director') : ( isset($row->about_the_director) ? $row->about_the_director : '')); ?></textarea>
			                                <?php $__errorArgs = ['about_the_director'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Brand Name</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="text" name="brand_name" value="<?php echo e(old('brand_name') ? old('brand_name') :( isset($row->brand_name) ? $row->brand_name : '')); ?>" class="form-control form-control-lg form-control-solid" maxlength="15"  placeholder="Enter Brand Name"/>
			                                <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Brand Logo </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                
			                            	<div class="image-input image-input-outline" id="brand_logo" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->brand_logo) && !empty($row->brand_logo)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->brand_logo)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper brand_logo_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="brand_logo" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="brand_logo_remove"/>
												</label>

												<?php if(isset($row->brand_logo) && !empty($row->brand_logo)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

			                                <?php $__errorArgs = ['brand_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">High res images of the Designers </label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                
			                            	<div class="image-input image-input-outline" id="high_res_images_of_the_designer_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_designer_1) && !empty($row->high_res_images_of_the_designer_1)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_designer_1)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_designer_1_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_designer_1" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_designer_1_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_designer_1) && !empty($row->high_res_images_of_the_designer_1)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

											<div class="image-input image-input-outline" id="high_res_images_of_the_designer_2" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_designer_2) && !empty($row->high_res_images_of_the_designer_2)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_designer_2)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_designer_2_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_designer_2" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_designer_2_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_designer_2) && !empty($row->high_res_images_of_the_designer_2)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

											<div class="image-input image-input-outline" id="high_res_images_of_the_designer_3" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_designer_3) && !empty($row->high_res_images_of_the_designer_3)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_designer_3)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_designer_3_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_designer_3" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_designer_3_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_designer_3) && !empty($row->high_res_images_of_the_designer_3)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

			                                <?php $__errorArgs = ['high_res_images_of_the_designer_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			                                <?php $__errorArgs = ['high_res_images_of_the_designer_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			                                <?php $__errorArgs = ['high_res_images_of_the_designer_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">High res images of the product</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                
			                            	<div class="image-input image-input-outline" id="high_res_images_of_the_product_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_product_1) && !empty($row->high_res_images_of_the_product_1)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_product_1)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_product_1_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_product_1" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_product_1_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_product_1) && !empty($row->high_res_images_of_the_product_1)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

											<div class="image-input image-input-outline" id="high_res_images_of_the_product_2" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_product_2) && !empty($row->high_res_images_of_the_product_2)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_product_2)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_product_2_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_product_2" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_product_2_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_product_2) && !empty($row->high_res_images_of_the_product_2)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

											<div class="image-input image-input-outline" id="high_res_images_of_the_product_3" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">

			                            		<?php if(isset($row->high_res_images_of_the_product_3) && !empty($row->high_res_images_of_the_product_3)): ?>
													<div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->high_res_images_of_the_product_3)); ?>)"></div>
			                            		<?php else: ?>
			                            			<div class="image-input-wrapper high_res_images_of_the_product_3_base64"></div>
			                            		<?php endif; ?>

												<label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change">
													<i class="fa fa-pen icon-sm text-muted"></i>
													<input type="file" name="high_res_images_of_the_product_3" accept=".png, .jpg, .jpeg"/>
													<input type="hidden" name="high_res_images_of_the_product_3_remove"/>
												</label>

												<?php if(isset($row->high_res_images_of_the_product_3) && !empty($row->high_res_images_of_the_product_3)): ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php else: ?>
													<span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel">
														<i class="ki ki-bold-close icon-xs text-muted"></i>
													</span>
			                            		<?php endif; ?>
											</div>

			                                <?php $__errorArgs = ['high_res_images_of_the_product_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			                                <?php $__errorArgs = ['high_res_images_of_the_product_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

			                                <?php $__errorArgs = ['high_res_images_of_the_product_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                </div>
			            </div>
	                    <!--end::Body-->

	                    <div class="card-footer">
			                <div class="row">
			                    <div class="col-lg-4"></div>
			                    <div class="col-lg-4 text-center">
			                        <button type="submit" class="btn btn-primary mr-2">Update</button>
			                    </div>
			                </div>
			            </div>
		            </form>

                </div>
                <!--end::Card-->
            </div>
            <!--end::Content-->
        </div>
        <!--end::Education-->
    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
    // START brand_logo
    var brand_logo = new KTImageInput('brand_logo');

	brand_logo.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	brand_logo.on('change', function(imageInput) {

		// swal.fire({
		// 	title: 'Image successfully uploaded !',
		// 	type: 'error',
		// 	buttonsStyling: false,
		// 	confirmButtonText: 'Okay!',
		// 	confirmButtonClass: 'btn btn-primary font-weight-bold'
		// });
		
	});

	brand_logo.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END brand_logo


	// START high_res_images_of_the_designer_1
    var high_res_images_of_the_designer_1 = new KTImageInput('high_res_images_of_the_designer_1');

	high_res_images_of_the_designer_1.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_designer_1.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_designer_1.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_designer_1

	// START high_res_images_of_the_designer_2
    var high_res_images_of_the_designer_2 = new KTImageInput('high_res_images_of_the_designer_2');

	high_res_images_of_the_designer_2.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_designer_2.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_designer_2.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_designer_2

	// START high_res_images_of_the_designer_3
    var high_res_images_of_the_designer_3 = new KTImageInput('high_res_images_of_the_designer_3');

	high_res_images_of_the_designer_3.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_designer_3.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_designer_3.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_designer_3

	// START high_res_images_of_the_product_1
    var high_res_images_of_the_product_1 = new KTImageInput('high_res_images_of_the_product_1');

	high_res_images_of_the_product_1.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_product_1.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_product_1.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_product_1

	// START high_res_images_of_the_product_2
    var high_res_images_of_the_product_2 = new KTImageInput('high_res_images_of_the_product_2');

	high_res_images_of_the_product_2.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_product_2.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_product_2.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_product_2

	// START high_res_images_of_the_product_3
    var high_res_images_of_the_product_3 = new KTImageInput('high_res_images_of_the_product_3');

	high_res_images_of_the_product_3.on('cancel', function(imageInput) {
		swal.fire({
			title: 'Image successfully canceled !',
			type: 'success',
			buttonsStyling: false,
			confirmButtonText: 'Okay!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});

	high_res_images_of_the_product_3.on('change', function(imageInput) {
		
	});

	high_res_images_of_the_product_3.on('remove', function(imageInput) {
		swal.fire({
			title: 'Image successfully removed !',
			type: 'error',
			buttonsStyling: false,
			confirmButtonText: 'Got it!',
			confirmButtonClass: 'btn btn-primary font-weight-bold'
		});
	});
	// END high_res_images_of_the_product_3

	
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/frontend/category_details/craft/edit.blade.php ENDPATH**/ ?>