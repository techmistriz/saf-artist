

<?php $__env->startSection('content'); ?>

<section class="saf-curatorpage">
	<div class="container">
		<div class="row pb-3">
			<div class="col-md-12">
				<h1 class="main-title">Curators</h1>
				<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt consectetur adipiscing.</p> 
			</div>
		</div>

		<div class="row">
		<?php if($curator->count()): ?>
        	<?php $__currentLoopData = $curator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4">
					<a href="<?php echo e(route('curator.details', ['id' => $value->id])); ?>">
						<div class="curator-card">
							<img src="<?php echo e(url('uploads/curators/thumbnails/250').'/'.$value->curator_image); ?>">
							<h3 class="name"><?php echo e($value->name); ?></h3>
							<p class="desgn"><?php echo e($value->discipline_name); ?></p>
						</div>
					</a>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

	<!-- 		<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/ricky-kej.jpg')); ?>">
						<h3 class="name">Ricky Kej</h3>
						<p class="desgn">Music</p>
					</div>
				</a>
			</div>

			<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/mayuri-upadhay.png')); ?>">
						<h3 class="name">Mayuri Upadhay</h3>
						<p class="desgn">dance</p>
					</div>
				</a>
			</div>


			<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/anjna-somany.png')); ?>">
						<h3 class="name">Anjna Somany</h3>
						<p class="desgn">Craft</p>
					</div>
				</a>
			</div>

			<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/ricky-kej.jpg')); ?>">
						<h3 class="name">Ricky Kej</h3>
						<p class="desgn">Music</p>
					</div>
				</a>
			</div>

			<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/mayuri-upadhay.png')); ?>">
						<h3 class="name">Mayuri Upadhay</h3>
						<p class="desgn">dance</p>
					</div>
				</a>
			</div>


			<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/anjna-somany.png')); ?>">
						<h3 class="name">Anjna Somany</h3>
						<p class="desgn">Craft</p>
					</div>
				</a>
			</div>

			<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/ricky-kej.jpg')); ?>">
						<h3 class="name">Ricky Kej</h3>
						<p class="desgn">Music</p>
					</div>
				</a>
			</div>

			<div class="col-md-4">
				<a href="#">
					<div class="curator-card">
						<img src="<?php echo e(url('/image/mayuri-upadhay.png')); ?>">
						<h3 class="name">Mayuri Upadhay</h3>
						<p class="desgn">dance</p>
					</div>
				</a>
			</div> -->

		</div>

	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/frontend/curators.blade.php ENDPATH**/ ?>