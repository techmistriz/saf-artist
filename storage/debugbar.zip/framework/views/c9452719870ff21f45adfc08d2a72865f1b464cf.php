<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
	.radio {
		display: -webkit-box;
	}

	.image-input {
	    margin-right: 10px;
	}

</style>
<div class="row">
    <div class="col-md-12">
        
        <div class="card card-custom gutter-b">
            <div class="card-header">
                <div class="card-title">
                    <h3 class="card-label"><?php echo e(isset($row) && !empty($row) ? 'Edit' : 'Add'); ?> <?php echo e($moduleConfig['moduleTitle']); ?> Category Details</h3>
                </div>
            </div>
            
            <div class="card-body">
                <div class="row">
                    
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Concept Note</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="file" name="concept_note"  class="form-control form-control-lg form-control-solid  <?php $__errorArgs = ['concept_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
                                <p class="text-muted small">Upload PDF (Name of file- Project Name + Artist Name)</p>
                                Uploaded File: 
                                <?php if($row->concept_note): ?>
                                    <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->concept_note)); ?>"><?php echo e($row->concept_note); ?></a>
                                <?php else: ?>
                                N/A
                                <?php endif; ?>
                                <?php $__errorArgs = ['concept_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Has this project been shown before</label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <select class="form-control form-control-lg form-control-solid selectpicker" name="has_this_project_show_before" tabindex="null" onchange="hasThisProjectShowBefore(this)">
                                    <option value="">Select</option>

                                    <option value="Yes" <?php echo e(old('has_this_project_show_before', $row->has_this_project_show_before ?? '') == 'Yes' ? 'selected' : ''); ?>>Yes</option>
                                    <option value="No" <?php echo e(old('has_this_project_show_before', $row->has_this_project_show_before ?? '') == 'No' ? 'selected' : ''); ?>>No</option>

                                </select>

                                <?php $__errorArgs = ['has_this_project_show_before'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>

                    <div class="col-6 reference-image-link-wrapper" style="display: <?php echo e(old('has_this_project_show_before', $row->has_this_project_show_before ?? '') == 'Yes' ? '' : 'none'); ?>">
                        <div class="form-group row validated">
                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Reference Image (Google drive link) </label>
                            <div class="col-lg-9 col-md-9 col-sm-12">
                                <input type="text" name="reference_image_link" value="<?php echo e(old('reference_image_link', $row->reference_image_link ?? '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Reference Image (Google drive link)"/>
                                <?php $__errorArgs = ['reference_image_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="card-footer">
                <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4 text-center">
                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                        <a class="btn btn-light-danger" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
    function hasThisProjectShowBefore(_this){

        if($(_this).val() == 'Yes'){
            $(".reference-image-link-wrapper").show();
        } else {

            $(".reference-image-link-wrapper").hide();
        }
    }

</script>
<?php $__env->stopPush(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/admin/user/category_details/forms/visual_arts/form.blade.php ENDPATH**/ ?>