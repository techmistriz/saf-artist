<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column-fluid">
    <div class="container">

        <div class="row">
            <div class="col-md-12">
                
                <div class="card card-custom gutter-b">
                    <div class="card-header">
                        <div class="card-title">
                            <h3 class="card-label">Show <?php echo e($moduleConfig['moduleTitle']); ?> Account Details</h3>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <div class="row">
                            
                            <div class="col-9">
                                
                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Are you registring for group: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->reg_for_group); ?></label>
                                        
                                    </div>
                                </div>
                                
                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Category: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->category->name ?? 'N/A'); ?></label>
                                    </div>
                                </div>
                                
                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Artist Type: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->artistType->name ?? 'N/A'); ?></label>
                                    </div>
                                </div>
                                
                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Name of Curators: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->curator_name ?? 'N/A'); ?></label>
                                    </div>
                                </div>
                                
                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Project Name: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->project->name ?? 'N/A'); ?></label>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Full Name: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->name); ?></label>
                                        
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">DOB: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->dob); ?></label>
                                    
                                    </div>
                                </div> 

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Contact: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->contact); ?></label>
                                    
                                    </div>
                                </div> 

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Email: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->email); ?></label>
                                    
                                    </div>
                                </div> 

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Address: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->permanent_address); ?></label>
                                    
                                    </div>
                                </div> 

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Country: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->PACountry->country_name ?? 'N/A'); ?></label>
                                        
                                    </div>
                                </div> 

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Country - Other: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->pa_country_other ?? 'N/A'); ?></label>
                                        
                                    </div>
                                </div> 

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">State: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->PAState->state_name ?? 'N/A'); ?></label>
                                        
                                    </div>
                                </div>  

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">City: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->PACity->city_name ?? 'N/A'); ?></label>
                                        
                                    </div>
                                </div>  

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">City - Other: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->pa_city_other ?? 'N/A'); ?></label>
                                        
                                    </div>
                                </div> 

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Pincode: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->pa_pincode); ?></label>
                                        
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Pincode: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->ca_pincode); ?></label>
                                        
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Stage Name (If Any): </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo e($row->stage_name); ?></label>
                                        
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Artist Bio: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">

                                        <label class="col-form-label text-lg-right"><?php echo $row->artist_bio; ?></label>
                                        
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Instagram URL: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->instagram_url); ?></label>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Facebook URL: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->facebook_url); ?></label>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Linkdin URL: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->linkdin_url); ?></label>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Twitter URL: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->twitter_url); ?></label>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Website <i>(If any)</i> : </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->website); ?></label>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Please upload 3 high resolutions images of your practice (for use on social media and print collaterals):</label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-4 col-sm-4">
                                                <div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">
                                                    <?php if(isset($row->practice_image_1) && !empty($row->practice_image_1)): ?>
                                                        <div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->practice_image_1)); ?>)"></div>
                                                    <?php else: ?>
                                                        <div class="image-input-wrapper"></div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="">
                                                    Uploaded File: 
                                                    <?php if($row->practice_image_1): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_1)); ?>"><?php echo e($row->practice_image_1); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-lg-4 col-md-4 col-sm-4">
                                                <div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">
                                                    <?php if(isset($row->practice_image_2) && !empty($row->practice_image_2)): ?>
                                                        <div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->practice_image_2)); ?>)"></div>
                                                    <?php else: ?>
                                                        <div class="image-input-wrapper"></div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="">
                                                    Uploaded File: 
                                                    <?php if($row->practice_image_2): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_2)); ?>"><?php echo e($row->practice_image_2); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-lg-4 col-md-4 col-sm-4">
                                                <div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">
                                                    <?php if(isset($row->practice_image_3) && !empty($row->practice_image_3)): ?>
                                                        <div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->practice_image_3)); ?>)"></div>
                                                    <?php else: ?>
                                                        <div class="image-input-wrapper"></div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="">
                                                    Uploaded File: 
                                                    <?php if($row->practice_image_3): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->practice_image_3)); ?>"><?php echo e($row->practice_image_3); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Please upload 2 high resolution profile images (For your festival ID and promotion): </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-4 col-sm-4">
                                                <div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">
                                                    <?php if(isset($row->profile_image_1) && !empty($row->profile_image_1)): ?>
                                                        <div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->profile_image_1)); ?>)"></div>
                                                    <?php else: ?>
                                                        <div class="image-input-wrapper"></div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="">
                                                    Uploaded File: 
                                                    <?php if($row->profile_image_1): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->profile_image_1)); ?>"><?php echo e($row->profile_image_1); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-lg-4 col-md-4 col-sm-4">
                                                <div class="image-input image-input-outline" id="program_image_1" style="background-image: url(<?php echo e(asset('media/users/blank.png')); ?>)">
                                                    <?php if(isset($row->profile_image_2) && !empty($row->profile_image_2)): ?>
                                                        <div class="image-input-wrapper" style="background-image: url(<?php echo e(asset('uploads/users/'.$row->profile_image_2)); ?>)"></div>
                                                    <?php else: ?>
                                                        <div class="image-input-wrapper"></div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="">
                                                    Uploaded File: 
                                                    <?php if($row->profile_image_2): ?>
                                                        <a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->profile_image_2)); ?>"><?php echo e($row->profile_image_2); ?></a>
                                                    <?php else: ?>
                                                    N/A
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Have you been associated with Serendipity Arts in the past ?: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->has_serendipity_arts); ?></label>
                                    </div>
                                </div>

                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Year: </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e(implode(', ', $row->year)); ?></label>
                                    </div>
                                </div>
                                
                                <div class="form-group row validated">
                                    <label class="col-form-label col-lg-3 col-sm-12 text-lg-left title-case">Link with videos of your work <i>(If any)</i> : </label>
                                    <div class="col-lg-9 col-md-9 col-sm-12">
                                        <label class="col-form-label text-lg-right"><?php echo e($row->other_link); ?></label>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="row">
                            <div class="col-lg-4"></div>
                            <div class="col-lg-4 text-center">
                                <a class="btn btn-primary" href="<?php echo e(route($moduleConfig['routes']['listRoute'])); ?>">Back</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/admin/user/show.blade.php ENDPATH**/ ?>