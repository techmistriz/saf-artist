<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column-fluid">
    <div class="container">

        <?php echo $__env->make('admin.includes.common.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
        <form action="<?php echo e(route($moduleConfig['routes']['updateCategoryDetailsRoute'], $row->user_id)); ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_method" value="PUT">
            <input type="hidden" name="id" value="<?php echo e($row->user_id); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo $__env->make('admin.'.$moduleConfig['viewCategoryDetailsFolder'].'.forms.'.$catViewFile.'.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
	function hasPartOfOtherProject(_this){

		if($(_this).val() == 'Yes'){
			$(".has-part-of-other-project").show();
		} else {

			$(".has-part-of-other-project").hide();
		}
	}

	function getProjects(_this, selectedId = 0) {

	    var other_project_category_id = $('#other_project_category_id').val();
	    if(other_project_category_id){
		    $.ajax({
				type: "GET",
				url: "<?php echo e(url('projects')); ?>/?category_id=" + other_project_category_id,
				datatype: 'json',
				success: function (response) {
					if(response?.status){
						var options = '<option value="">Select Project</option>';
						if(response.data.length) {
							for (var i = 0; i < response.data.length; i++) {

								var _selected = '';

								if(selectedId == response.data[i].id){

									_selected = 'selected';
								}

								options += '<option '+_selected+' value="'+response.data[i].id+'">'+response.data[i].name+'</option>';
							}

							$("#other_project_id").html(options);
							$("#other_project_id").selectpicker('refresh');
						}
					}
				}
			});
	    } else {
	    	$("#other_project_id").html('<option value="">Select Project</option>');
	    	$("#other_project_id").selectpicker('refresh');
	    }
    }

    $(document).ready(function(){
		
		getProjects(null, <?php echo old( 'other_project_id', $row->other_project_id ?? 0 )?>);

	});

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/admin/user/category_details/edit.blade.php ENDPATH**/ ?>