<?php 
    $helper     =   new \App\Helpers\Helper;
?>
<div class="aside-menu-wrapper flex-column-fluid" id="kt_aside_menu_wrapper">
    <!--begin::Menu Container-->
    <div id="kt_aside_menu" class="aside-menu my-4" data-menu-vertical="1" data-menu-scroll="1" data-menu-dropdown-timeout="500">
        <!--begin::Menu Nav-->
        <ul class="menu-nav">
            <li class="menu-item menu-item-active <?php echo e($helper->isActivate(['home'])); ?>" aria-haspopup="true">
                <a href="#" class="menu-link">
                    <span class="svg-icon menu-icon">
                        <i class="flaticon-layer"></i>
                    </span>
                    <span class="menu-text">Dashboard</span>
                </a>
            </li>
            
            <?php
            $rolePermissionArr = session('rolePermission');

            ?>

            <?php if(@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN'): ?>
            	<?php echo $__env->make('admin/includes/sidebar/admin_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('UserController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN'): ?>
            	<?php echo $__env->make('admin/includes/sidebar/role', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('VenueController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/venue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            
            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('VibeController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/vibe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            
            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('CuratorController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/curator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('MediaController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            
            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('ProgramController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/program', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('ContactusController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/contact_us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <li class="menu-section">
                <h4 class="menu-text">Masters</h4>
                <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
            </li>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('DisciplineController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/discipline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('AccessibilityController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/accessibility', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('CategoryController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('ProgramTagController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/program_tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <?php if(@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN'): ?>
            	<?php echo $__env->make('admin/includes/sidebar/admin_module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            
            <!-- New Section Start -->
            <li class="menu-section">
                <h4 class="menu-text">Settings</h4>
                <i class="menu-icon ki ki-bold-more-hor icon-md"></i>
            </li>

            <?php if(
            	@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN' ||
            	in_array('SmsTemplateController', @$rolePermissionArr['permissions']) ||
            	in_array('EmailTemplateController', @$rolePermissionArr['permissions'])
        	): ?>
            	<?php echo $__env->make('admin/includes/sidebar/template', $rolePermissionArr, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

         	<?php if(@$rolePermissionArr['roleCode'] == 'SUPER_ADMIN'): ?>
            	<?php echo $__env->make('admin/includes/sidebar/system_settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </ul>
        <!--end::Menu Nav-->
    </div>
    <!--end::Menu Container-->
</div><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/admin/includes/sidebar/menu.blade.php ENDPATH**/ ?>