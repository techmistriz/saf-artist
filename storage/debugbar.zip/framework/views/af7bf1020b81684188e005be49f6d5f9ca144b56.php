

<?php $__env->startSection('content'); ?>

<section class="saf-vibepage">
    <div class="container">

        <div class="row pb-3">
            <div class="col-md-12">
                <h1 class="main-title">Vibes</h1>
                <p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt consectetur adipiscing.</p> 
            </div>
        </div>

        <div class="row">
            <?php if($partners->count()): ?>
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <h2 class="block-title">Partner <?php echo e($value->name); ?></h2>
                    </div>
                    <div class="col-md-12">
                        <div class="saf-partner hotels">
                            <?php if($vibes->count()): ?>
                                <?php $__currentLoopData = $vibes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key->partner_type_id == $value->id): ?>
                                        <div class="single-item single-item-<?php echo e($value->id); ?>">
                                            <img src="<?php echo e(url('uploads/vibes/').'/'.$key->featured_image); ?>" alt="" width="100%" >
                                            <h3 class="title"><?php echo e($key->name); ?></h3>
                                            <p class="short-desc"><?php echo e($key->short_description); ?></p>
                                            <!-- <p class="long-desc" style="display: none"><?php echo e($key->description); ?></p> -->
                                            <!-- <p class="external-link" style="display: none"><?php echo e($key->external_link); ?></p> -->
                                            <!-- <a href="javascript:void(0)" onclick="openKnowMoreModal( <?php echo e($key->id); ?> )" class="link-btn">Know More &LongRightArrow;</a> -->
                                            <a href="javascript:void(0)" data-toggle="modal" data-target="#knowMoreModal<?php echo e($key->id); ?>" class="link-btn">Know More &LongRightArrow;</a>
                                           
                                        </div>
                                        
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>  
    </div>
</section>


<?php if($partners->count()): ?>
    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($vibes->count()): ?>
            <?php $__currentLoopData = $vibes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value2->partner_type_id == $value1->id): ?>
                    <div class="modal fade" id="knowMoreModal<?php echo e($value2->id); ?>" tabindex="-1" role="dialog" aria-labelledby="knowMoreModalLabel<?php echo e($value2->id); ?>" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="knowMoreModalLabel<?php echo e($value2->id); ?>">Information</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <i aria-hidden="true" class="ki ki-close"></i>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <?php echo e($value2->description); ?>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Close</button>
                                    <a href="<?php echo e($value2->external_link); ?>" target="_blank" class="btn btn-primary font-weight-bold external-link-btn">Visit Site</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
   <script type="text/javascript">

        function openKnowMoreModal(id){

            // var description = $(".single-item-" + id + " .long-desc").html();
            // var external_link = $(".single-item-" + id + " .external-link").text();

            // console.log("id", id);
            // console.log("external_link", external_link);

            // $("#knowMoreModal .modal-body").html(description);
            // $("#knowMoreModal .external-link-btn").attr('href', '');
            // $("#knowMoreModal .external-link-btn").attr('href', external_link);
            // $("#knowMoreModal").modal('toggle');
        }

        // $(document).ready(function(){

        //     $(document).on('show.bs.modal','#knowMoreModal', function(e) {

        //         alert('Hi');
        //     });
        // });

   </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/frontend/vibes.blade.php ENDPATH**/ ?>