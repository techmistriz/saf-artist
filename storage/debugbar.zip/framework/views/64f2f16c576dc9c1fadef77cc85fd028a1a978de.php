[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>