<?php echo e($slot); ?>

<?php /**PATH D:\system\wamp64\www\saf-artist\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>