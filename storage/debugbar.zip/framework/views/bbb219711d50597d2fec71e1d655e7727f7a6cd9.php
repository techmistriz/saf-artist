

<?php $__env->startSection('content'); ?>


<section class="saf-exhibitionpage">
	<div class="container">

		<div class="row pb-3">
			<div class="col-md-12">
				<h1 class="main-title">Exhibitions</h1>
				<p class="sub-title">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt consectetur adipiscing.</p> 
			</div>
		</div>
		
		<!-- filter code -->
		<div class="row">
			<div class="col-md-12">
				<form method="" class="searchform">				
					<div class="form-group">
						<label for="searchbar">search programes</label>
						<input type="text" class="form-control" name="search" placeholder="Search events, descriptions....">
                	</div>
					<div class="row">
						<div class="col-md-12">
							<h4 class="fltr-title">Filter</h4>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<select name="type" class="form-control">
									<option value="0">Select Type</option>
									<?php if($programTags->count()): ?>
	        							<?php $__currentLoopData = $programTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
	        							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        							<?php endif; ?>
								</select>
							</div>
						</div>

						<div class="col-md-3">
							<div class="form-group">
								<select name="genre" class="form-control">
									<option value="0">Select Genre</option>
									<?php if($disciplines->count()): ?>
	        							<?php $__currentLoopData = $disciplines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
	        							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        							<?php endif; ?>
								</select>
							</div>
						</div>

						<div class="col-md-3">
							<div class="form-group">
								<select name="accesiblity" class="form-control">
									<option value="0">Select Accessibility</option>
									<?php if($accessibilities->count()): ?>
	        							<?php $__currentLoopData = $accessibilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
	        							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        							<?php endif; ?>
								</select>
							</div>
						</div>

						<div class="col-md-3">
						<div class="form-group">
								<select name="dates" class="form-control">
									<option value="0">dates</option>
									<option value="1">June 20 23</option>
									<option value="2">June 28 23</option>
									<option value="3">June 30 23</option>
									<option value="4">July 05 23</option>
								</select>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>


		<div class="row pb-3">
			<div class="col-md-12">
				<div class="showing-results">
					<p class="result">showing <span><?php echo e($programs->count()); ?></span> of <span><?php echo e($programs->count()); ?></span></p>
				</div>
			</div>
		</div>

		<div class="row pb-3">

			<?php if($programs->count()): ?>
	        	<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <div class="col-md-10 exhibitionsingle">
						<div class="row">
							<div class="col-md-5">
								<div class="exhibition-item">
									<p class="date"><?php echo e($value->formatEventDateTime()); ?></p>
									<div class="imgtag">
										<img src="<?php echo e(url('uploads/programs/thumbnails/250').'/'.$value->program_image); ?>" class="pgrimg">
										<?php

										$programTags = $value->programTags();

										?>

										<?php if($programTags): ?>
											<div class="tags">
			        						<?php $__currentLoopData = $programTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="tag-col"><?php echo e($value2); ?></div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
										<?php endif; ?>
									</div>
									<a class="link-btn" href="#">book seats ⟶</a>
								</div>
							</div>
							<div class="col-md-7">
								<div class="exhibition-item-content">
									<h3 class="title"><?php echo e($value->discipline->name ?? 'N/A'); ?></h3>
									<p class="desc"><?php echo $value->description; ?></p>
									<div class="icon">
										<i class="fa fa-heart" aria-hidden="true"></i>
										<i class="fa fa-universal-access" aria-hidden="true"></i>
										<i class="fa fa-share" aria-hidden="true"></i>
										<i class="fa fa-bell" aria-hidden="true"></i>
									</div>
								</div>
							</div>
						</div>

					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        <?php endif; ?>

		</div>

	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/frontend/exhibitions.blade.php ENDPATH**/ ?>