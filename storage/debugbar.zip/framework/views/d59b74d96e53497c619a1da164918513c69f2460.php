<div class="flex-row-auto offcanvas-mobile w-300px w-xl-325px" id="kt_profile_aside">
    <!--begin::Nav Panel Widget 2-->
    <div class="card card-custom gutter-b">
        <!--begin::Body-->
        <div class="card-body">
            <!--begin::Wrapper-->
            <div class="d-flex justify-content-between flex-column pt-4 h-100">
                <!--begin::Container-->
                <div class="pb-5">
                    <!--begin::Header-->
                    <div class="d-flex flex-column flex-center">
                        <!--begin::Symbol-->
                        <div class="symbol symbol-120 symbol-circle symbol-success overflow-hidden">
                            <span class="symbol-label">

                        	<?php if(!empty(Auth::user()->profile_image_1)): ?>
                        	<img src="<?php echo e(asset('uploads/users/'.Auth::user()->profile_image_1)); ?>" class="h-75 align-self-end" alt="">
                    		<?php else: ?>
                    			<img src="<?php echo e(asset('media/users/007-boy-2.svg')); ?>" class="h-75 align-self-end" alt="">
                    		<?php endif; ?>
                            </span>
                        </div>
                        <!--end::Symbol-->
                        <!--begin::Username-->
                        <a href="<?php echo e(route('dashboard')); ?>" class="card-title font-weight-bolder text-dark-75 text-hover-primary font-size-h4 m-0 pt-7 pb-1"><?php echo e(Auth::user()->name); ?></a>
                        <!--end::Username-->
                        <!--begin::Info-->
                        <div class="font-weight-bold text-dark-50 font-size-sm pb-6"><?php echo e(Auth::user()->email); ?></div>
                        <!--end::Info-->
                    </div>
                    <!--end::Header-->
                    <!--begin::Body-->
                    <div class="pt-1">
                        
                        <!--begin::Item-->
                        <div class="d-flex align-items-center pb-9">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-45 symbol-light mr-4">
                                <span class="symbol-label">
                                    <i class="la la-user-edit icon-xl"></i>
                                </span>
                            </div>
                            <!--end::Symbol-->
                            <!--begin::Text-->
                            <div class="d-flex flex-column flex-grow-1">
                                <a href="<?php echo e(route('edit.category.details')); ?>" class="text-dark-75 text-hover-primary mb-1 font-size-lg font-weight-bolder">Category Details</a>
                                <span class="text-muted font-weight-bold">Category Details</span>
                            </div>
                            <!--end::Text-->
                        </div>

                        <div class="d-flex align-items-center pb-9">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-45 symbol-light mr-4">
                                <span class="symbol-label">
                                    <i class="la la-bank  icon-xl"></i>
                                </span>
                            </div>
                            <!--end::Symbol-->

                            <!--begin::Text-->
                            <div class="d-flex flex-column flex-grow-1">
                                <a href="<?php echo e(route('edit.account.details')); ?>" class="text-dark-75 text-hover-primary mb-1 font-size-lg font-weight-bolder">Account Details</a>
                                <span class="text-muted font-weight-bold">Account Details</span>
                            </div>
                            <!--end::Text-->
                        </div>

                        <div class="d-flex align-items-center pb-9">
                            <!--begin::Symbol-->
                            <div class="symbol symbol-45 symbol-light mr-4">
                                <span class="symbol-label">
                                    <i class="la la-sign-out  icon-xl"></i>
                                </span>
                            </div>
                            <!--end::Symbol-->

                            <!--begin::Text-->
                            <div class="d-flex flex-column flex-grow-1">
                                <a href="<?php echo e(route('edit.account.details')); ?>" class="text-dark-75 text-hover-primary mb-1 font-size-lg font-weight-bolder" onclick="event.preventDefault(); document.getElementById('logout-form-header').submit();">Logout</a>

                                <form id="logout-form-header" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
				                    <?php echo e(csrf_field()); ?>

			                  	</form>

                                <span class="text-muted font-weight-bold">Logout from your account</span>
                            </div>
                            <!--end::Text-->
                        </div>

                        <!--end::Item-->
                    </div>
                    <!--end::Body-->
                </div>
                <!--eng::Container-->
                
            </div>
            <!--end::Wrapper-->
        </div>
        <!--end::Body-->
    </div>
    <!--end::Nav Panel Widget 2-->
    
</div><?php /**PATH E:\system\wamp\www\Others\artist\resources\views/frontend/includes/aside.blade.php ENDPATH**/ ?>