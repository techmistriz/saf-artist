<?php $__env->startSection('content'); ?>
<style type="text/css">
	.image-input {
	    margin-right: 10px;
	}
	.image-input .image-input-wrapper {
	    width: 85px;
	    height: 85px;
	}
	.bootstrap-select>.dropdown-toggle.btn-light, .bootstrap-select>.dropdown-toggle.btn-secondary {
	    height: calc(1.5em + 1.65rem + 2px);
	    padding: 0.825rem 1.42rem;
	    font-size: 1.08rem;
	    line-height: 1.5;
	    border-radius: 0.42rem;
        background-color: #f3f6f9 !important;
    	border-color: #f3f6f9 !important;
	}
</style>
<div class="d-flex flex-column-fluid">
    <!--begin::Container-->
    <div class=" container ">
        <!--begin::Education-->
        <div class="d-flex flex-row">
            <!--begin::Aside-->
            <?php echo $__env->make('frontend/includes/aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--end::Aside-->
            <!--begin::Content-->
            <div class="flex-row-fluid ml-lg-8">

            	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            	
                <!--begin::Card-->
                <div class="card card-custom gutter-bs">

                    <!--Begin::Header-->
                    <div class="card-header">
		                <div class="card-title">
		                    <h3 class="card-label">Project Category Details</h3>
		                </div>
		            </div>
                    <!--end::Header-->

                    <!--Begin::Body-->
                    <div class="card-body1">

                    	<!-- include('frontend/category_details/category_form') -->
                    </div>
                    <!--end::Body-->

                	<form action="<?php echo e(route('update.category.details')); ?>" method="POST" enctype="multipart/form-data">
			            <input type="hidden" name="_method" value="PUT">
			            <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
			            <?php echo e(csrf_field()); ?>


	                    <!--Begin::Body-->
	                    <div class="card-body">
			                <div class="row">
			                    
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Concept Note</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <input type="file" name="concept_note"  class="form-control form-control-lg form-control-solid  <?php $__errorArgs = ['concept_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " />
			                                <p class="text-muted small">Upload PDF (Name of file- Project Name + Artist Name)</p>
			                                Uploaded File: 
			                                <?php if($row->concept_note): ?>
			                                	<a target="_blank" href="<?php echo e(asset('uploads/users/'.$row->concept_note)); ?>"><?php echo e($row->concept_note); ?></a>
			                            	<?php else: ?>
			                            	N/A
			                            	<?php endif; ?>
			                                <?php $__errorArgs = ['concept_note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>
			                    <div class="col-12">
			                        <div class="form-group row validated">
			                            <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Has this project been shown before</label>
			                            <div class="col-lg-9 col-md-9 col-sm-12">
			                                <select class="form-control form-control-lg form-control-solid selectpicker" name="has_this_project_show_before" tabindex="null" onchange="hasThisProjectShowBefore(this)">
			                                    <option value="">Select</option>

			                                    <option value="Yes" <?php echo e(old('has_this_project_show_before', $row->has_this_project_show_before ?? '') == 'Yes' ? 'selected' : ''); ?>>Yes</option>
			                                    <option value="No" <?php echo e(old('has_this_project_show_before', $row->has_this_project_show_before ?? '') == 'No' ? 'selected' : ''); ?>>No</option>

			                                </select>

			                                <?php $__errorArgs = ['has_this_project_show_before'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
			                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			                            
			                            </div>
			                        </div>
			                    </div>

			                    <div class="col-12 reference-image-link-wrapper" style="display: <?php echo e(old('has_this_project_show_before', $row->has_this_project_show_before ?? '') == 'Yes' ? '' : 'none'); ?>">
                                    <div class="form-group row validated">
                                        <label class="col-form-label col-lg-3 col-sm-12 text-lg-left">Reference Image (Google drive link) </label>
                                        <div class="col-lg-9 col-md-9 col-sm-12">
                                            <input type="text" name="reference_image_link" value="<?php echo e(old('reference_image_link', $row->reference_image_link ?? '')); ?>" class="form-control form-control-lg form-control-solid"   placeholder="Enter Reference Image (Google drive link)"/>
                                            <?php $__errorArgs = ['reference_image_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                        </div>
                                    </div>
                                </div>
			                    
			                </div>
			            </div>
	                    <!--end::Body-->

	                    <div class="card-footer">
			                <div class="row">
			                	<?php if(\Auth::user()->is_freeze == 0): ?>
			                    <div class="col-lg-4"></div>
			                    <div class="col-lg-4 text-center">
			                        <button type="submit" class="theme-btn mt-0 mb-0">Update</button>
			                    </div>
			                    <?php else: ?>
			                    	<div class="col-lg-12">
			                    		<p class="text-center text-danger small italic">Your account has been freeze by admin hence you are not able to update any of details.</p>
			                    	</div>
			                    <?php endif; ?>
			                </div>
			            </div>
		            </form>

                </div>
                <!--end::Card-->
            </div>
            <!--end::Content-->
        </div>
        <!--end::Education-->
    </div>
    <!--end::Container-->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    
	function hasThisProjectShowBefore(_this){

		if($(_this).val() == 'Yes'){
			$(".reference-image-link-wrapper").show();
		} else {

			$(".reference-image-link-wrapper").hide();
		}
	}

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/saf23demoserver/artist.demoserver.co.in/resources/views/frontend/category_details/visual_arts/edit.blade.php ENDPATH**/ ?>