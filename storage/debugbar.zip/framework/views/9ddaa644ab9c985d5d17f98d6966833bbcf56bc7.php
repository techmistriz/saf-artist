

<?php $__env->startSection('content'); ?>

<section class="curatorsingle-section">
	<div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="gotoback">
                    <a href="<?php echo e(route('curators')); ?>">⟵ Back</a>
                <div>
            </div>
        </div>
		<div class="row">
            <div class="col-md-1">
            	<?php if($prevCurator): ?>
                	<div class="left-arrow"><a href="<?php echo e(route('curator.details', ['id' => $prevCurator->id])); ?>">⟵</a></div>
                <?php endif; ?>
            </div>
            <div class="col-md-5">
                <div class="profile-img">
                    <img src="<?php echo e(url('uploads/curators/thumbnails/250').'/'.$curator->curator_image); ?>">
                </div>
            </div>
            <div class="col-md-5">
                <div class="profile-title">
                    <h3><?php echo e($curator->name); ?></h3> 
                    <div class="seperator-box"></div>
                    <span><?php echo e($curator->discipline_name); ?></span>
                </div>
                <div class="profile-info">
                    <?php echo $curator->bio; ?>

                </div>
            </div>
            <div class="col-md-1">
            	<?php if($nextCurator): ?>
                	<div class="right-arrow"><a href="<?php echo e(route('curator.details', ['id' => $nextCurator->id])); ?>">⟶</a></div>
                <?php endif; ?>
            </div>
        </div>

	    <div class="row">
	        <div class="explore-curators">
	            <h3 class="main-title">
	                Explore more curators
	            </h3>

	            <div class="scroll-curators">

	            	<?php if($otherCurators->count()): ?>
	        			<?php $__currentLoopData = $otherCurators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <div class="single-item">
			        			<a href="<?php echo e(route('curator.details', ['id' => $value->id])); ?>" style="display: block;">
					                    <div class="row">
					                        <div class="col-md-3">
					                            <img src="<?php echo e(url('uploads/curators/thumbnails/250').'/'.$value->curator_image); ?>">
					                        </div>
					                        <div class="col-md-9">
					                            <h3 class="title"><?php echo e($value->name); ?></h3>
					                            <p class="desg"><?php echo e($value->discipline_name); ?></p>
					                        </div>
					                    </div>
					            </a>
			                </div>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                <?php endif; ?>
	            </div>
	        </div>
	    </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\system\wamp\www\Others\laravel-shivam-event\resources\views/frontend/curator-single.blade.php ENDPATH**/ ?>